import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { createHash } from "node:crypto";
import { Prisma } from "@prisma/client";
import { AdmissionNumberService } from "../admissions/admission-number.service";
import { PrismaService } from "../prisma/prisma.service";
import type { AuthUser } from "../common/auth-user";
import { RealtimeEventsService } from "../realtime/realtime-events.service";
import { SubscriptionSyncPolicyService } from "./subscription-sync-policy.service";
import {
  DEFAULT_SYNC_PULL_LIMIT,
  MAX_SYNC_PULL_LIMIT,
  PlatformCacheDto,
  PullSyncDto,
  PushSyncDto,
  RegisterSyncDeviceDto,
  ResolveSyncConflictDto,
  SyncPushRecordDto,
  WorkspaceBootstrapDto,
  type SyncPullCursor,
} from "./dto/sync.dto";
import {
  BLOCKED_PUSH_TABLES,
  BRANCH_REQUIRED_TABLES,
  LOCAL_FIRST_TABLES,
  LOCAL_FIRST_SYNC_TABLE_NAMES,
  PLATFORM_CACHE_TABLE_NAMES,
  SCHOOL_REQUIRED_TABLES,
  WORKSPACE_BOOTSTRAP_SCHEMA_VERSION,
  WORKSPACE_BOOTSTRAP_TABLES,
  type WorkspaceBootstrapRole,
  validateSyncTableRegistry,
} from "./sync-table-registry";


/**
 * Phase 2 note: existing synchronization behaviour is preserved here.
 * Subscription quota enforcement is introduced in the dedicated enforcement phase.
 *
 * Phase 4 pull pagination:
 * - stable cursor: updatedAt + id;
 * - bounded page sizes;
 * - deterministic ascending order;
 * - no timestamp-only record loss when many records share updatedAt.
 */

type SyncResult = {
  tableName: string;
  localId: string;
  cloudId?: string;
  version: number;
  updatedAt: number;
  ok: boolean;
  error?: string;
  conflictId?: string;
  admissionNumber?: string;
  admissionNumberConfirmed?: boolean;
};

/**
 * localId is a permanent client-generated UUID string.
 * It must remain unchanged through validation, persistence, conflict handling,
 * pull responses, media ownership and result output.
 */
type NormalizedSyncPushRecord = Omit<SyncPushRecordDto, "localId"> & {
  localId: string;
};

/** Membership-authorized scope, never selected from untrusted client IDs. */
type WorkspaceReadScope = {
  role: WorkspaceBootstrapRole;
  schoolId?: string;
  branchId?: string;
  teacherId?: string;
  studentId?: string;
  parentId?: string;
};

/**
 * Display fields permitted for colleagues sharing an assigned class.
 * The source SyncRecord remains unchanged in PostgreSQL.
 */
const COLLEAGUE_TEACHER_DISPLAY_FIELDS = [
  "id", "accountId", "schoolId", "branchId", "fullName", "displayName",
  "name", "firstName", "middleName", "lastName", "surname",
  "otherNames", "preferredName", "title", "prefix", "suffix",
  "active", "isDeleted", "createdAt", "updatedAt", "version",
] as const;

/**
 * Browser-push allow-list for local-first Dexie tables.
 *
 * IMPORTANT:
 * This backend list must match the frontend local-first sync registry.
 * If a table exists in Dexie/PUSH_SYNC_TABLES but is missing here,
 * pushSync will fail with: "<table> is not allowed to be pushed from the browser."
 */
const MEDIA_ASSETS_TABLE = "mediaAssets";

/**
 * Media fields that contain collections rather than one replaceable asset.
 * Every item in these fields must keep its own SyncRecord and remain active
 * beside sibling assets owned by the same record.
 */
const MULTI_MEDIA_FIELD_KEYS = new Set([
  "gallery",
  "schoolGalleryImages",
]);

const SAFE_MEDIA_ASSET_FIELDS = new Set([
  "accountId",
  "schoolId",
  "branchId",
  "cloudId",
  "ownerTable",
  "ownerId",
  "ownerTempKey",
  "fieldKey",
  "ownerIdentityKey",
  "identityVersion",
  "fileName",
  "originalFileName",
  "extension",
  "mimeType",
  "assetKind",
  "sizeBytes",
  "originalSizeBytes",
  "width",
  "height",
  "durationMs",
  "checksum",
  "thumbnailDataUrl",
  "previewDataUrl",
  "remoteUrl",
  "publicUrl",
  "remoteKey",
  "remoteProvider",
  "uploadStatus",
  "uploadedAt",
  "lastUploadAttemptAt",
  "uploadError",
  "metadata",
  "active",
  "isDeleted",
  "createdAt",
  "updatedAt",
  "version",
  "deviceId",
]);

@Injectable()
export class SyncService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly realtime: RealtimeEventsService,
    private readonly syncPolicy: SubscriptionSyncPolicyService,
    private readonly admissionNumbers: AdmissionNumberService,
  ) {
    const registryIssues = validateSyncTableRegistry();
    if (registryIssues.length) {
      throw new Error(
        [
          "Invalid backend sync table registry:",
          ...registryIssues.map((issue) => `- ${issue}`),
        ].join("\n"),
      );
    }
  }

  async status(user?: { accountId?: string; email?: string; role?: string }) {
    const access = user?.accountId
      ? await this.syncPolicy.resolve({
          accountId: user.accountId,
          role: user.role,
        })
      : null;

    return {
      ok: true,
      service: "Eleeveon Sync Service",
      workspaceBootstrapSchemaVersion:
        WORKSPACE_BOOTSTRAP_SCHEMA_VERSION,
      accountId: user?.accountId,
      user: user?.email,
      role: user?.role,
      syncPolicy: access,
      registry: {
        localFirstTables: LOCAL_FIRST_SYNC_TABLE_NAMES.length,
        platformCacheTables: PLATFORM_CACHE_TABLE_NAMES.length,
      },
      serverTime: Date.now(),
    };
  }

  async policy(actor: AuthUser) {
    const accountId = this.requireActorAccount(
      actor,
      actor.accountId,
    );

    if (!accountId) {
      throw new BadRequestException(
        "Account session is missing. Please log out and sign in again.",
      );
    }

    await this.ensureAccount(accountId);

    return this.syncPolicy.resolveFrontendPolicy({
      accountId,
      role: actor.role,
    });
  }

  async push(actor: AuthUser, dto: PushSyncDto) {
    const results: SyncResult[] = [];
    const changedTables = new Set<string>();
    const accountId = this.requireActorAccount(actor, dto.accountId);

    if (!accountId) {
      return {
        ok: false,
        results: [],
        serverTime: Date.now(),
        error: "Account session is missing. Please log out and sign in again.",
      };
    }

    await this.ensureAccount(accountId);
    await this.syncPolicy.assertCanPush(actor, accountId);
    await this.touchDevice({
      accountId,
      deviceId: dto.deviceId,
      lastPushAt: new Date(),
    });

    for (const record of dto.records || []) {
      try {
        const tableName = this.cleanTableName(record.tableName);

        if (!tableName) throw new BadRequestException("Missing table name.");

        if (BLOCKED_PUSH_TABLES.has(tableName) || !LOCAL_FIRST_TABLES.has(tableName)) {
          throw new ForbiddenException(`${tableName} is not allowed to be pushed from the browser.`);
        }

        const localId = this.requireLocalId(
          record.localId,
          tableName,
        );

        const normalizedRecord: NormalizedSyncPushRecord = {
          ...record,
          tableName,
          accountId,
          localId,
          cloudId: this.cleanString(record.cloudId),
          deviceId: this.cleanString(record.deviceId || dto.deviceId),
          version: Number(record.version || 1),
          updatedAt: Number(record.updatedAt || Date.now()),
          isDeleted: Boolean(record.isDeleted),
          payload: this.sanitizePayload(record.payload || {}, tableName),
        };

        await this.validateIncomingSyncRecord(
          actor,
          normalizedRecord,
          accountId,
        );

        const saved = await this.upsertRecord(normalizedRecord);

        results.push({
          tableName,
          localId: normalizedRecord.localId,
          cloudId: saved.id,
          version: saved.version,
          updatedAt: Number(saved.updatedAt),
          ok: true,
          ...(tableName === "students" && !saved.isDeleted
            ? { admissionNumber: String((saved.payload as any)?.admissionNumber || "") || undefined, admissionNumberConfirmed: Boolean((saved.payload as any)?.admissionNumberConfirmed) }
            : {}),
        });

        changedTables.add(tableName);
      } catch (error: any) {
        results.push({
          tableName: record.tableName,
          localId: this.cleanString(record.localId) || "",
          cloudId: this.cleanString(record.cloudId) || undefined,
          version: Number(record.version || 1),
          updatedAt: Number(record.updatedAt || Date.now()),
          ok: false,
          error: this.safeSyncError(error),
        });
      }
    }

    if (changedTables.size > 0) {
      this.realtime.emitAccountDataChanged({
        accountId,
        changedTables: [...changedTables],
        sourceDeviceId: dto.deviceId,
        metadata: {
          action: "sync-push",
          successfulRecords: results.filter((item) => item.ok).length,
        },
      });
    }

    return { ok: results.every((item) => item.ok), results, serverTime: Date.now() };
  }

  /**
   * Role- and membership-authorized incremental pull.
   *
   * A caller cannot upgrade itself by choosing another role or a table name.
   * The active JWT user must own the selected, active membership. Scope and
   * profile IDs are taken from that membership, not trusted from the request.
   *
   * Legacy clients that omit membershipId work ONLY if exactly one active
   * membership exists. Multi-role clients must send membershipId explicitly.
   *
   * Since a number of relations (parent/child, teacher/media ownership) are
   * stored in SyncRecord JSON, scoped pulls currently materialize the role's
   * candidate dataset before filtering and paging. This is network-paginated,
   * not database-streamed; indexed relationship tables will be needed to
   * improve performance at large scale.
   */
  async pull(actor: AuthUser, dto: PullSyncDto) {
    const accountId = this.requireActorAccount(actor, dto.accountId);
    await this.ensureAccount(accountId);
    await this.syncPolicy.assertCanPull(actor, accountId);

    if (!this.cleanString(actor.id)) {
      throw new ForbiddenException("The authenticated user identity is missing.");
    }

    const membershipId = this.cleanId(dto.membershipId);
    const memberships = await this.prisma.userMembership.findMany({
      where: {
        accountId,
        userId: actor.id,
        active: true,
        status: "active",
        ...(membershipId ? { id: membershipId } : {}),
      },
      orderBy: { createdAt: "asc" },
      take: membershipId ? 1 : 2,
    });

    if (!memberships.length) {
      throw new ForbiddenException(
        "The selected synchronization membership is unavailable or inactive.",
      );
    }
    if (!membershipId && memberships.length !== 1) {
      throw new ForbiddenException(
        "Select an active workspace membership before synchronization.",
      );
    }

    const membership = memberships[0];
    const membershipRole = this.normalizeWorkspaceRole(membership.role);
    const requestedRole = dto.role
      ? this.normalizeWorkspaceRole(dto.role)
      : membershipRole;
    // Historical school-admin memberships may store role="admin".
    // Using school_admin in that case is equivalent or narrower; other role
    // substitutions are forbidden.
    if (
      requestedRole !== membershipRole &&
      !(membershipRole === "admin" && requestedRole === "school_admin")
    ) {
      throw new ForbiddenException("The selected role does not match the membership.");
    }
    const role = requestedRole;

    const accountWide = ["developer", "platform_team", "super_admin"].includes(role);
    const schoolId = this.cleanId(membership.schoolId);
    const branchId = this.cleanId(membership.branchId);
    const teacherId = this.cleanId(membership.teacherId);
    const studentId = this.cleanId(membership.studentId);
    const parentId = this.cleanId(membership.parentId);

    // A school/branch/profile-limited membership MUST carry its own stored
    // scope. Never borrow another membership's scope or a client-supplied ID.
    if (!accountWide && !schoolId) {
      throw new ForbiddenException("The selected membership has no school scope.");
    }
    if (["branch_admin", "accountant", "teacher", "student", "parent"].includes(role) && !branchId) {
      throw new ForbiddenException("The selected membership has no branch scope.");
    }
    if (role === "teacher" && !teacherId) {
      throw new ForbiddenException("The teacher profile is not linked to this membership.");
    }
    if (role === "student" && !studentId) {
      throw new ForbiddenException("The student profile is not linked to this membership.");
    }
    if (role === "parent" && !parentId) {
      throw new ForbiddenException("The parent profile is not linked to this membership.");
    }

    for (const field of ["schoolId", "branchId", "teacherId", "studentId", "parentId"] as const) {
      const requested = this.cleanId(dto[field]);
      const assigned = this.cleanId(membership[field]);
      // Account-wide members may use school/branch UI selectors without
      // reducing their authorization. School admins may likewise select a
      // branch within their school; this pull always uses their stored scope.
      if (
        requested && !accountWide &&
        !(field === "branchId" && ["admin", "school_admin"].includes(role) && !assigned) &&
        requested !== assigned
      ) {
        throw new ForbiddenException(
          `The requested ${field} is outside this selected membership.`,
        );
      }
    }

    const roleTables = this.workspaceBootstrapTables(role).sort();
    const allowedTables = new Set(roleTables);
    const requestedTables = Array.isArray(dto.tableNames)
      ? dto.tableNames.map((table) => this.cleanString(table))
      : [];
    if (requestedTables.some((table) => !table || !allowedTables.has(table))) {
      throw new ForbiddenException(
        "A requested synchronization table is not allowed for this membership.",
      );
    }
    const tables = requestedTables.length
      ? [...new Set(requestedTables as string[])].sort()
      : roleTables;
    const selectedTables = new Set(tables);

    const pageLimit = Number(dto.limit ?? DEFAULT_SYNC_PULL_LIMIT);
    if (!Number.isInteger(pageLimit) || pageLimit < 1 || pageLimit > MAX_SYNC_PULL_LIMIT) {
      throw new BadRequestException(
        `Synchronization limit must be between 1 and ${MAX_SYNC_PULL_LIMIT}.`,
      );
    }

    const cursor = this.resolvePullCursor(dto);
    const since = cursor ? 0 : Number(dto.since ?? 0);
    if (!Number.isSafeInteger(since) || since < 0) {
      throw new BadRequestException("Invalid synchronization since timestamp.");
    }

    let page: any[];
    let hasMore: boolean;
    const readScope: WorkspaceReadScope = {
      role, schoolId, branchId, teacherId, studentId, parentId,
    };

    if (accountWide) {
      // Owner/platform memberships do not need relationship filtering. Keep
      // their incremental pull on indexed, bounded Prisma queries instead of
      // loading the account's complete record collection for every page.
      const fetched = await this.prisma.syncRecord.findMany({
        where: {
          accountId,
          tableName: { in: tables },
          ...(cursor
            ? {
                OR: [
                  { updatedAt: { gt: BigInt(cursor.updatedAt) } },
                  {
                    AND: [
                      { updatedAt: BigInt(cursor.updatedAt) },
                      { id: { gt: cursor.id } },
                    ],
                  },
                ],
              }
            : since > 0
              ? { updatedAt: { gt: BigInt(since) } }
              : {}),
        },
        orderBy: [{ updatedAt: "asc" }, { id: "asc" }],
        take: pageLimit + 1,
      });
      hasMore = fetched.length > pageLimit;
      page = fetched.slice(0, pageLimit);
    } else {
      // Relationship-derived role filters require parent/student and media
      // owner records even when they are outside the requested table subset.
      const candidates = await this.prisma.syncRecord.findMany({
        where: {
          accountId,
          tableName: { in: roleTables },
        },
        orderBy: [{ updatedAt: "asc" }, { id: "asc" }],
      });

      const scope: WorkspaceReadScope = {
        role, schoolId, branchId, teacherId, studentId, parentId,
      };
      const scoped = this.filterWorkspaceBootstrapRecords(candidates, scope);
      const afterCursor = (record: any) => {
        if (!cursor) return BigInt(record.updatedAt) > BigInt(since);
        const updatedAt = BigInt(record.updatedAt);
        const pivot = BigInt(cursor.updatedAt);
        return updatedAt > pivot ||
          (updatedAt === pivot && String(record.id) > cursor.id);
      };

      // These cursors and page counts consider ONLY authorized records.
      const eligible = scoped.filter((record) =>
        selectedTables.has(record.tableName) && afterCursor(record),
      );
      hasMore = eligible.length > pageLimit;
      page = eligible.slice(0, pageLimit);
    }
    const lastRecord = page.length ? page[page.length - 1] : null;
    const nextCursor: SyncPullCursor | null = lastRecord
      ? { updatedAt: Number(lastRecord.updatedAt), id: lastRecord.id }
      : cursor;

    const records: any[] = [];
    const quarantineRecords: any[] = [];
    for (const record of page) {
      const integrity = await this.validateStoredPullRecord(
        actor, record, accountId,
      );
      // Invalid UUIDs must be quarantined rather than throwing and blocking
      // every later record. No unverified row is returned outside the scope.
      if (integrity.ok) {
        records.push(this.toBootstrapPullRecord(record, readScope));
      } else {
        quarantineRecords.push(this.toQuarantinePullRecord(
          record, integrity.reason || "INVALID_PULL_RECORD", readScope,
        ));
      }
    }

    // Detect a revocation that happens while the page is being assembled.
    const stillActive = await this.prisma.userMembership.findFirst({
      where: {
        id: membership.id,
        accountId,
        userId: actor.id,
        active: true,
        status: "active",
        updatedAt: membership.updatedAt,
      },
      select: { id: true },
    });
    if (!stillActive) {
      throw new ForbiddenException(
        "Workspace membership changed during synchronization. Select your role again.",
      );
    }

    await this.touchDevice({
      accountId,
      userId: actor.id,
      deviceId: dto.deviceId,
      lastPullAt: new Date(),
    });

    return {
      records,
      quarantineRecords,
      membershipId: membership.id,
      role,
      accountId,
      serverTime: Date.now(),
      hasMore,
      nextCursor,
      pageSize: page.length,
      validPageSize: records.length,
      quarantinedPageSize: quarantineRecords.length,
      requestedLimit: pageLimit,
    };
  }


  /**
   * Phase 21 priority workspace bootstrap.
   *
   * This endpoint is intentionally separate from the ordinary incremental pull:
   * - the authenticated JWT account remains authoritative;
   * - one active membership selects the permitted workspace;
   * - only role-essential tables are returned;
   * - records are tenant-scoped and integrity-validated;
   * - the client can apply the complete bundle in one Dexie transaction before
   *   opening the selected portal.
   */
  async workspaceBootstrap(
    actor: AuthUser,
    dto: WorkspaceBootstrapDto,
  ) {
    // Strict opt-in: older frontend builds receive the original full bundle.
    if (dto.pageSize !== undefined || Boolean(dto.cursor)) {
      return this.workspaceBootstrapPaged(actor, dto);
    }

    const accountId =
      this.requireActorAccount(
        actor,
        dto.accountId,
      );

    await this.ensureAccount(
      accountId,
    );

    await this.syncPolicy.assertCanWorkspaceBootstrap(
      actor,
      accountId,
    );

    await this.touchDevice({
      accountId,
      userId: actor.id,
      deviceId: dto.deviceId,
      lastPullAt: new Date(),
      lastSeenAt: new Date(),
    });

    const membership =
      await this.resolveWorkspaceMembership(
        actor,
        dto,
      );

    const role =
      this.normalizeWorkspaceRole(
        dto.role ||
          membership.role ||
          actor.role,
      );

    const schoolId =
      this.cleanId(
        dto.schoolId ??
          membership.schoolId,
      );

    const branchId =
      this.cleanId(
        dto.branchId ??
          membership.branchId,
      );

    const teacherId =
      this.cleanId(
        dto.teacherId ??
          membership.teacherId,
      );

    const studentId =
      this.cleanId(
        dto.studentId ??
          membership.studentId,
      );

    const parentId =
      this.cleanId(
        dto.parentId ??
          membership.parentId,
      );

    await this.assertWorkspaceScope({
      actor,
      role,
      schoolId,
      branchId,
      teacherId,
      studentId,
      parentId,
    });

    const roleTables = this.workspaceBootstrapTables(role);
    const tables = this.workspaceBootstrapTables(role, dto.tableNames);
    const selectedTables = new Set(tables);

    // Teacher/parent relationships must be derived from the FULL role dataset.
    // Fetching only a requested subset (for example, teachers) loses the
    // classSubjects/classTeachers links needed to authorize those profiles.
    const fetched = await this.prisma.syncRecord.findMany({
      where: {
        accountId,
        tableName: { in: roleTables },
      },
      orderBy: [{ updatedAt: "asc" }, { id: "asc" }],
    });

    const readScope: WorkspaceReadScope = {
      role, schoolId, branchId, teacherId, studentId, parentId,
    };
    const scoped = this.filterWorkspaceBootstrapRecords(fetched, readScope)
      .filter((record) => selectedTables.has(record.tableName));

    const records: any[] = [];
    const quarantineRecords: any[] = [];
    const changedTables =
      new Set<string>();

    const tableCounts: Record<string, number> = {};

    for (const record of scoped) {
      const integrity =
        await this.validateStoredPullRecord(
          actor,
          record,
          accountId,
        );

      if (integrity.ok) {
        records.push(this.toBootstrapPullRecord(record, readScope));
        changedTables.add(record.tableName);
        tableCounts[record.tableName] =
          (tableCounts[record.tableName] || 0) + 1;
      } else {
        quarantineRecords.push(this.toQuarantinePullRecord(
          record, integrity.reason || "INVALID_BOOTSTRAP_RECORD", readScope,
        ));
      }
    }

    const workspace =
      this.buildWorkspaceSummary(
        records,
        {
          role,
          schoolId,
          branchId,
          teacherId,
          studentId,
          parentId,
        },
      );

    const platformCache =
      await this.lightweightWorkspacePlatformCache(
        actor,
        accountId,
      );

    const bootstrapRevision =
      this.buildWorkspaceBootstrapRevision({
        accountId,
        membershipId:
          membership.id,
        role,
        schoolId,
        branchId,
        records,
        platformRecords:
          platformCache.records,
      });

    return {
      ok: true,
      accountId,
      membershipId:
        membership.id,
      role,
      schoolId,
      branchId,
      teacherId,
      studentId,
      parentId,
      workspace,

      // Explicit fields for the first-entry appearance handoff. Keep workspace
      // for backward compatibility with existing clients.
      school: workspace.school,
      branch: workspace.branch,
      schoolBranchSettings:
        workspace.settings,
      requiredTables: tables,
      completed: true,

      records,
      cacheRecords:
        platformCache.records,
      quarantineRecords,
      changedTables:
        [...changedTables],

      // The frontend stores these values in the scoped readiness marker.
      // An old or partial marker is never accepted as a complete workspace.
      bootstrapSchemaVersion:
        WORKSPACE_BOOTSTRAP_SCHEMA_VERSION,
      includedTables:
        tables,
      tablesWithRecords:
        Object.keys(tableCounts),

      bootstrapRevision,
      revision: bootstrapRevision,
      serverTime:
        Date.now(),
      recordCount:
        records.length,
      totalRecords:
        records.length + platformCache.records.length,
      tableCounts,
      quarantinedCount:
        quarantineRecords.length,
      truncated: false,
    };
  }

  /**
   * Paginated, role-authorized workspace-bootstrap response.
   *
   * COMPATIBILITY: activated only by pageSize/cursor. Legacy requests still
   * receive the unchanged one-response bundle from workspaceBootstrap().
   *
   * The current data model keeps relationship-based roles in JSON SyncRecords.
   * To avoid incorrect parent/media access, this first implementation builds
   * the complete authorized candidate set and then pages its result. Thus it
   * saves NETWORK bandwidth and lets the client commit incrementally, but it
   * is not database-side streaming. Replace with indexed, snapshot-consistent
   * SQL/Prisma paging when those relationships are available as indexed data.
   *
   * A cursor is bound to account, membership, selected profiles, selected
   * tables, page size, and a SHA-256 revision of the ordered scoped dataset.
   * When that dataset changes, the caller MUST restart the page traversal.
   */
  private async workspaceBootstrapPaged(
    actor: AuthUser,
    dto: WorkspaceBootstrapDto,
  ) {
    const accountId = this.requireActorAccount(actor, dto.accountId);
    await this.ensureAccount(accountId);
    await this.syncPolicy.assertCanWorkspaceBootstrap(actor, accountId);

    const membership = await this.resolveWorkspaceMembership(actor, dto);
    const role = this.normalizeWorkspaceRole(membership.role);
    const schoolId = this.cleanId(dto.schoolId ?? membership.schoolId);
    const branchId = this.cleanId(dto.branchId ?? membership.branchId);
    const teacherId = this.cleanId(dto.teacherId ?? membership.teacherId);
    const studentId = this.cleanId(dto.studentId ?? membership.studentId);
    const parentId = this.cleanId(dto.parentId ?? membership.parentId);

    await this.assertWorkspaceScope({
      actor, role, schoolId, branchId, teacherId, studentId, parentId,
    });

    const roleTables = this.workspaceBootstrapTables(role).sort();
    const allowed = new Set(roleTables);
    const requested = Array.isArray(dto.tableNames)
      ? dto.tableNames.map((table) => this.cleanTableName(table))
      : [];

    // Do not silently fall back to ALL tables after an invalid narrow request.
    if (requested.some((table) => !table || !allowed.has(table))) {
      throw new ForbiddenException(
        "A requested workspace table is not allowed for this membership.",
      );
    }

    const tables = requested.length
      ? [...new Set(requested as string[])].sort()
      : roleTables;
    const selected = new Set(tables);
    const pageSize = Number(dto.pageSize ?? 150);
    if (!Number.isInteger(pageSize) || pageSize < 1 || pageSize > 500) {
      throw new BadRequestException("pageSize must be between 1 and 500.");
    }

    // Relationship resolution must see ALL role-permitted tables, not only
    // `tableNames`: parent->child and media->owner depend on other tables.
    const candidates = await this.prisma.syncRecord.findMany({
      where: { accountId, tableName: { in: roleTables } },
      orderBy: [{ updatedAt: "asc" }, { id: "asc" }],
    });

    const scope: WorkspaceReadScope = {
      role, schoolId, branchId, teacherId, studentId, parentId,
    };
    const roleScoped = this.filterWorkspaceBootstrapRecords(candidates, scope);
    const eligible = roleScoped.filter((record) => selected.has(record.tableName));

    // The role/table authorization and this ordered record-set digest bind
    // every page. Invalidated snapshots restart rather than skip records.
    const scopeKey = [
      accountId, membership.id, role, schoolId || "", branchId || "",
      teacherId || "", studentId || "", parentId || "", tables.join(","),
    ].join("|");
    const revision = createHash("sha256")
      .update(scopeKey)
      .update(JSON.stringify(eligible.map((record) => [
        record.id,
        record.tableName,
        String(record.updatedAt),
        record.version,
        Boolean(record.isDeleted),
      ])))
      .digest("hex");

    let offset = 0;
    if (dto.cursor) {
      if (dto.cursor.length > 4096) {
        throw new BadRequestException("Invalid workspace page cursor.");
      }
      let decoded: {
        v?: number;
        scopeKey?: string;
        revision?: string;
        offset?: number;
        pageSize?: number;
      };
      try {
        decoded = JSON.parse(
          Buffer.from(dto.cursor, "base64url").toString("utf8"),
        );
      } catch {
        throw new BadRequestException("Invalid workspace cursor encoding.");
      }
      if (
        decoded?.v !== 1 ||
        decoded.scopeKey !== scopeKey ||
        decoded.pageSize !== pageSize ||
        !Number.isSafeInteger(decoded.offset) ||
        (decoded.offset ?? -1) < 0 ||
        (decoded.offset ?? 0) >= eligible.length
      ) {
        throw new BadRequestException(
          "Workspace cursor does not match the requested membership, tables or page size.",
        );
      }
      if (decoded.revision !== revision) {
        throw new BadRequestException(
          "WORKSPACE_SNAPSHOT_CHANGED: Restart workspace download from page one.",
        );
      }
      offset = decoded.offset!;
    }

    const page = eligible.slice(offset, offset + pageSize);
    const hasMore = offset + page.length < eligible.length;
    const nextCursor = hasMore
      ? Buffer.from(JSON.stringify({
          v: 1, scopeKey, revision, offset: offset + page.length, pageSize,
        })).toString("base64url")
      : null;

    // Revalidate current membership before sending page data. This check is
    // necessary but cannot substitute for immediate permission revocation in
    // a previously cached offline client.
    await this.resolveWorkspaceMembership(actor, {
      ...dto,
      membershipId: membership.id,
    });

    const records: any[] = [];
    const quarantineRecords: any[] = [];
    const changedTables = new Set<string>();
    const tableCounts: Record<string, number> = {};

    for (const record of page) {
      const integrity = await this.validateStoredPullRecord(
        actor, record, accountId,
      );
      // Never throw for invalid UUIDs before quarantining them.
      if (integrity.ok) {
        records.push(this.toBootstrapPullRecord(record, scope));
        changedTables.add(record.tableName);
        tableCounts[record.tableName] =
          (tableCounts[record.tableName] || 0) + 1;
      } else {
        quarantineRecords.push(this.toQuarantinePullRecord(
          record, integrity.reason || "INVALID_BOOTSTRAP_RECORD", scope,
        ));
      }
    }

    // Compute presentation data from the FULL scoped set. Its school/branch
    // metadata is useful on the first page regardless of the requested table.
    const workspace = this.buildWorkspaceSummary(
      roleScoped.map((record) => ({
        tableName: record.tableName,
        localId: record.localId,
        payload: record.payload,
      })),
      scope,
    );

    const platformCache = offset === 0
      ? await this.lightweightWorkspacePlatformCache(actor, accountId)
      : { records: [] as any[] };

    await this.touchDevice({
      accountId,
      userId: actor.id,
      deviceId: dto.deviceId,
      lastPullAt: new Date(),
      lastSeenAt: new Date(),
    });

    return {
      ok: true,
      accountId,
      membershipId: membership.id,
      role, schoolId, branchId, teacherId, studentId, parentId,
      workspace,
      school: workspace.school,
      branch: workspace.branch,
      schoolBranchSettings: workspace.settings,
      requiredTables: tables,
      roleRequiredTables: roleTables,
      allRoleTablesRequested: tables.length === roleTables.length,
      completed: !hasMore,
      hasMore,
      nextCursor,
      pageSize,
      pageOffset: offset,
      records,
      cacheRecords: platformCache.records,
      quarantineRecords,
      changedTables: [...changedTables],
      bootstrapSchemaVersion: WORKSPACE_BOOTSTRAP_SCHEMA_VERSION,
      includedTables: tables,
      // This page's populated tables. Individual page results alone must
      // NEVER be treated as proof of full workspace/table completeness.
      tablesWithRecords: Object.keys(tableCounts),
      bootstrapRevision: revision,
      revision,
      serverTime: Date.now(),
      recordCount: records.length,
      // This is the full number of role-scoped rows BEFORE integrity rejection.
      totalRecords: eligible.length + platformCache.records.length,
      tableCounts,
      quarantinedCount: quarantineRecords.length,
      truncated: false,
    };
  }

  async bootstrap(user: { id?: string; accountId?: string; email?: string; role?: string }, dto?: PlatformCacheDto) {
    const accountId = this.cleanId(dto?.accountId || user.accountId);
    if (!accountId) throw new BadRequestException("Account session is missing.");

    await this.ensureAccount(accountId);
    await this.syncPolicy.assertCanPlatformCache(
      user as AuthUser,
      accountId,
    );
    await this.touchDevice({
      accountId,
      userId: user.id,
      deviceId: dto?.deviceId,
      lastSeenAt: new Date(),
    });

    const [platformCache, syncStatus] = await Promise.all([
      this.platformCache(user as AuthUser, { accountId, deviceId: dto?.deviceId, since: dto?.since }),
      this.diagnostics(user as AuthUser, accountId),
    ]);

    return {
      ok: true,
      accountId,
      serverTime: Date.now(),
      platformCache,
      syncStatus,
    };
  }

  async platformCache(actor: AuthUser, dto: PlatformCacheDto) {
    const accountId = this.requireActorAccount(actor, dto.accountId);
    if (!accountId) throw new BadRequestException("Account session is missing.");

    await this.ensureAccount(accountId);
    await this.syncPolicy.assertCanPlatformCache(actor, accountId);
    await this.touchDevice({
      accountId,
      deviceId: dto.deviceId,
      lastSeenAt: new Date(),
    });

    const sinceDate = dto.since ? new Date(Number(dto.since)) : undefined;
    const records: any[] = [];
    const unavailableTables: string[] = [];
    const prisma = this.prisma as unknown as Record<string, any>;

    const add = (tableName: string, rowOrRows: any) => {
      const rows = Array.isArray(rowOrRows)
        ? rowOrRows
        : rowOrRows
          ? [rowOrRows]
          : [];

      for (const row of rows) {
        const payload = this.sanitizePlatformCachePayload(
          tableName,
          this.toPlain(row),
        );

        records.push({
          tableName,
          id: payload.id || payload.accountId,
          cloudId: payload.id || payload.accountId,
          accountId,
          updatedAt: payload.updatedAt || payload.createdAt || Date.now(),
          isDeleted: false,
          payload,
        });
      }
    };

    const query = async (
      tableName: string,
      delegateName: string,
      methodName: "findUnique" | "findMany",
      args: Record<string, unknown>,
    ) => {
      const delegate = prisma[delegateName];
      const method = delegate?.[methodName];

      if (typeof method !== "function") {
        unavailableTables.push(tableName);
        return;
      }

      try {
        const result =
          await method.call(
            delegate,
            args,
          );

        add(tableName, result);
      } catch (error) {
        unavailableTables.push(
          tableName,
        );

        console.warn(
          `[sync:platform-cache] ${tableName} could not be loaded.`,
          error instanceof Error
            ? error.message
            : String(error),
        );
      }
    };

    await Promise.all([
      query("accounts", "account", "findUnique", { where: { id: accountId } }),
      query("appUsers", "appUser", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 1000 }),
      query("userMemberships", "userMembership", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 2000 }),
      query("permissionRules", "permissionRule", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" } }),
      query("userSessions", "userSession", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 100 }),

      query("commercialPlans", "commercialPlan", "findMany", { where: { active: true }, orderBy: { createdAt: "asc" } }),
      query("subscriptionPlans", "subscriptionPlan", "findMany", { where: { active: true }, orderBy: { priceMonthly: "asc" } }),
      query("accountSubscriptions", "accountSubscription", "findUnique", { where: { accountId }, include: { plan: true } }),
      query("subscriptionPeriods", "subscriptionPeriod", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("subscriptionChangeOrders", "subscriptionChangeOrder", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("privateOffers", "privateOffer", "findMany", { where: { active: true }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("privateOfferAssignments", "privateOfferAssignment", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("pricingOverrides", "accountPricingOverride", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("accountUsageSnapshots", "accountUsageSnapshot", "findMany", { where: { accountId }, orderBy: { calculatedAt: "desc" }, take: 24 }),
      query("accountEntitlements", "accountEntitlement", "findUnique", { where: { accountId } }),

      query("perpetualLicenses", "perpetualLicense", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" } }),
      query("licenseActivations", "licenseActivation", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query(
        "licenseValidationEvents",
        "licenseValidationEvent",
        "findMany",
        {
          where: {
            accountId,
          },
          orderBy: {
            validatedAt: "desc",
          },
          take: 100,
        },
      ),
      query("licenseUpgradeOffers", "licenseUpgradeOffer", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),

      query("supportedLocales", "supportedLocale", "findMany", { where: { active: true }, orderBy: { code: "asc" } }),
      query("accountLocaleSettings", "accountLocaleSetting", "findUnique", { where: { accountId } }),
      query("userLocalePreferences", "userLocalePreference", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 1000 }),
      query("membershipLocalePreferences", "membershipLocalePreference", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 2000 }),

      query(
        "platformReleases",
        "platformRelease",
        "findMany",
        {
          where: {
            status: "published",
          },
          orderBy: [
            {
              publishedAt: "desc",
            },
            {
              createdAt: "desc",
            },
          ],
          take: 50,
        },
      ),
      query(
        "platformAnnouncements",
        "platformAnnouncement",
        "findMany",
        {
          where: {
            status: "published",
            AND: [
              {
                OR: [
                  {
                    startsAt: null,
                  },
                  {
                    startsAt: {
                      lte: new Date(),
                    },
                  },
                ],
              },
              {
                OR: [
                  {
                    expiresAt: null,
                  },
                  {
                    expiresAt: {
                      gt: new Date(),
                    },
                  },
                ],
              },
            ],
          },
          orderBy: [
            {
              publishedAt: "desc",
            },
            {
              createdAt: "desc",
            },
          ],
          take: 100,
        },
      ),

      query("platformReleaseNotes", "platformReleaseNote", "findMany", { where: { active: true }, orderBy: { createdAt: "desc" }, take: 200 }),
      query("invoices", "invoice", "findMany", { where: { accountId, ...(sinceDate ? { updatedAt: { gte: sinceDate } } : {}) }, orderBy: { updatedAt: "desc" }, take: 100 }),
      query("appPayments", "appPayment", "findMany", { where: { accountId, ...(sinceDate ? { updatedAt: { gte: sinceDate } } : {}) }, orderBy: { updatedAt: "desc" }, take: 100 }),
      query("billingEvents", "billingEvent", "findMany", { where: { accountId, ...(sinceDate ? { createdAt: { gte: sinceDate } } : {}) }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("syncDevices", "syncDevice", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 100 }),
      query("syncConflicts", "syncConflict", "findMany", { where: { accountId, status: { in: ["open", "resolved", "ignored"] } }, orderBy: { detectedAt: "desc" }, take: 100 }),
      query("apiClients", "apiClient", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 100 }),
      query("apiKeys", "apiKey", "findMany", { where: { accountId, active: true }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("webhooks", "webhook", "findMany", { where: { accountId }, orderBy: { updatedAt: "desc" }, take: 100 }),
      query("webhookLogs", "webhookLog", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("integrationMappings", "integrationMapping", "findMany", { where: { accountId, active: true }, orderBy: { updatedAt: "desc" }, take: 500 }),
      query("auditLogs", "auditLog", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("backgroundJobs", "backgroundJob", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
      query("storageUsages", "storageUsage", "findUnique", { where: { accountId } }),
      query("accountFeatureFlags", "accountFeatureFlag", "findMany", { where: { accountId }, orderBy: { key: "asc" } }),
      query("accountSystemSettings", "accountSystemSetting", "findMany", { where: { accountId }, orderBy: { key: "asc" } }),
      query("notificationDeliveryLogs", "notificationDeliveryLog", "findMany", { where: { accountId }, orderBy: { createdAt: "desc" }, take: 100 }),
    ]);

    return {
      ok: true,
      records,
      serverTime: Date.now(),
      requestedTables: PLATFORM_CACHE_TABLE_NAMES.length,
      returnedTables: [...new Set(records.map((record) => record.tableName))],
      unavailableTables: [...new Set(unavailableTables)],
    };
  }

  private sanitizePlatformCachePayload(
    tableName: string,
    payload: Record<string, any>,
  ) {
    const sanitized = { ...payload };

    for (const key of [
      "password", "encryptedPassword", "passwordSalt", "passwordHash",
      "secret", "secretHash", "token", "tokenHash", "refreshToken",
      "refreshTokenHash", "resetToken", "verificationToken",
      "privateKey", "apiKeyHash", "challenge", "challengeHash",
    ]) {
      delete sanitized[key];
    }

    if (tableName === "apiKeys") {
      delete sanitized.key;
      delete sanitized.rawKey;
    }

    if (tableName === "userSessions") {
      delete sanitized.refreshToken;
      delete sanitized.accessToken;
    }

    return sanitized;
  }

  async registerDevice(user: { id?: string; accountId?: string }, dto: RegisterSyncDeviceDto) {
    const accountId = this.cleanId(dto.accountId || user.accountId);
    const deviceId = this.cleanString(dto.deviceId);

    if (!accountId || !deviceId) {
      throw new BadRequestException("accountId and deviceId are required.");
    }

    await this.ensureAccount(accountId);

    const access = await this.syncPolicy.resolve({
      accountId,
      role: (user as AuthUser).role,
    });

    const device = await this.prisma.syncDevice.upsert({
      where: { accountId_deviceId: { accountId, deviceId } },
      update: {
        userId: dto.userId || user.id || undefined,
        name: dto.name || dto.deviceName || undefined,
        platform: dto.platform || "web",
        syncPolicy: access.syncPolicy,
        lastSeenAt: new Date(),
        active: true,
      },
      create: {
        accountId,
        userId: dto.userId || user.id || undefined,
        deviceId,
        name: dto.name || dto.deviceName || undefined,
        platform: dto.platform || "web",
        syncPolicy: access.syncPolicy,
        lastSeenAt: new Date(),
        active: true,
      },
    });

    return { ok: true, device: { ...this.toPlain(device), deviceName: device.name } };
  }

  async listConflicts(actor: AuthUser, status = "open") {
    const cleanAccountId = this.requireActorAccount(actor);
    if (!cleanAccountId) throw new BadRequestException("accountId is required.");

    const conflicts = await this.prisma.syncConflict.findMany({
      where: { accountId: cleanAccountId, ...(status ? { status } : {}) },
      orderBy: { detectedAt: "desc" },
      take: 200,
    });

    return { conflicts: conflicts.map((c) => this.toPlain(c)), serverTime: Date.now() };
  }

  async resolveConflict(actor: AuthUser, conflictId: string, dto: ResolveSyncConflictDto) {
    const accountId = this.requireActorAccount(actor);
    await this.syncPolicy.assertCanResolveConflicts(
      actor,
      accountId,
    );
    const userId = actor.id;
    const conflict = await this.prisma.syncConflict.findUnique({ where: { id: conflictId } });

    if (!conflict || conflict.accountId !== accountId) {
      throw new NotFoundException("Conflict not found.");
    }

    const updated = await this.prisma.syncConflict.update({
      where: { id: conflictId },
      data: {
        status: "resolved",
        resolutionPayload: dto.resolutionPayload || conflict.serverPayload || conflict.clientPayload || undefined,
        note: dto.note || dto.resolution,
        resolvedAt: new Date(),
        resolvedByUserId: userId,
      },
    });

    return { ok: true, conflict: this.toPlain(updated) };
  }

  async diagnostics(actor: AuthUser, requestedAccountId?: string) {
    const actorAccountId = this.requireActorAccount(actor);
    const normalizedRole = String(actor.role || "").toLowerCase();
    const mayCrossAccounts = ["developer", "platform_team"].includes(normalizedRole);
    const accountId = mayCrossAccounts
      ? this.cleanId(requestedAccountId) || actorAccountId
      : actorAccountId;
    const where = { accountId };

    const [total, deleted, conflicts, devices, tables] = await Promise.all([
      this.prisma.syncRecord.count({ where }),
      this.prisma.syncRecord.count({ where: { ...where, isDeleted: true } }),
      this.prisma.syncConflict.count({ where: { accountId, status: "open" } }),
      this.prisma.syncDevice.count({ where: { accountId, active: true } }),
      this.prisma.syncRecord.groupBy({
        by: ["tableName"],
        where,
        _count: { tableName: true },
        orderBy: { _count: { tableName: "desc" } },
      }),
    ]);

    return { total, deleted, conflicts, devices, tables };
  }

  private requireActorAccount(
    actor: AuthUser,
    suppliedAccountId?: string | null,
  ) {
    const jwtAccountId = this.cleanId(actor?.accountId);
    const requestAccountId = this.cleanId(suppliedAccountId);

    if (!jwtAccountId) {
      throw new ForbiddenException(
        "The authenticated session has no accountId.",
      );
    }

    if (
      requestAccountId &&
      requestAccountId !== jwtAccountId
    ) {
      throw new ForbiddenException(
        "The request accountId does not match the authenticated JWT accountId.",
      );
    }

    return jwtAccountId;
  }

  private async actorTenantScope(actor: AuthUser) {
    const accountId = this.requireActorAccount(actor);
    const userId = this.cleanString(actor?.id);
    const role = String(actor?.role || "").trim().toLowerCase();

    if (!userId) {
      throw new ForbiddenException(
        "The authenticated session has no user id.",
      );
    }

    const memberships =
      await this.prisma.userMembership.findMany({
        where: {
          accountId,
          userId,
          active: true,
        },
        select: {
          role: true,
          schoolId: true,
          branchId: true,
          active: true,
        },
      });

    if (!memberships.length) {
      throw new ForbiddenException(
        "No active membership grants access to this account.",
      );
    }

    const roles = new Set([
      role,
      ...memberships.map((membership) =>
        String(membership.role || "").toLowerCase(),
      ),
    ]);

    const accountWide =
      roles.has("developer") ||
      roles.has("platform_team") ||
      roles.has("super_admin") ||
      memberships.some(
        (membership) =>
          ["super_admin", "admin"].includes(
            String(membership.role || "").toLowerCase(),
          ) &&
          !membership.schoolId &&
          !membership.branchId,
      );

    const schoolIds = new Set<string>();
    const branchIds = new Set<string>();

    for (const membership of memberships) {
      const schoolId = this.cleanId(membership.schoolId);
      const branchId = this.cleanId(membership.branchId);
      if (schoolId) schoolIds.add(schoolId);
      if (branchId) branchIds.add(branchId);
    }

    return {
      accountId,
      accountWide,
      schoolIds,
      branchIds,
    };
  }

  private tenantIdsForRecord(
    tableName: string,
    payload: Record<string, any>,
    localId?: string,
  ) {
    const schoolId = this.cleanId(
      payload.schoolId ||
        (tableName === "schools" ? payload.id || localId : undefined),
    );

    const branchId = this.cleanId(
      payload.branchId ||
        (tableName === "branches" ? payload.id || localId : undefined),
    );

    return { schoolId, branchId };
  }

  private async assertActorTenantAccess(
    actor: AuthUser,
    tableName: string,
    payload: Record<string, any>,
    localId?: string,
  ) {
    const scope = await this.actorTenantScope(actor);

    if (scope.accountWide) return;

    const { schoolId, branchId } =
      this.tenantIdsForRecord(tableName, payload, localId);

    if (branchId) {
      if (!scope.branchIds.has(branchId)) {
        throw new ForbiddenException(
          `${tableName} belongs to a branch outside the authenticated user's membership scope.`,
        );
      }

      if (schoolId && !scope.schoolIds.has(schoolId)) {
        throw new ForbiddenException(
          `${tableName} belongs to a school outside the authenticated user's membership scope.`,
        );
      }

      return;
    }

    if (schoolId) {
      if (!scope.schoolIds.has(schoolId)) {
        throw new ForbiddenException(
          `${tableName} belongs to a school outside the authenticated user's membership scope.`,
        );
      }

      return;
    }

    // Account-level records are visible to any active account membership.
  }


  private appearanceScopeForWorkspaceRole(
    role: WorkspaceBootstrapRole,
  ): "platform" | "account" | "school" | "branch" {
    if (["developer", "platform_team"].includes(role)) {
      return "platform";
    }

    if (role === "super_admin") {
      return "account";
    }

    if (["admin", "school_admin"].includes(role)) {
      return "school";
    }

    return "branch";
  }

  private normalizeWorkspaceRole(
    value?: string | null,
  ): WorkspaceBootstrapRole {
    const role =
      String(value || "")
        .trim()
        .toLowerCase()
        .replace(/-/g, "_");

    const aliases:
      Record<
        string,
        WorkspaceBootstrapRole
      > = {
      owner: "super_admin",
      school_owner:
        "super_admin",
      schooladmin:
        "school_admin",
      branchadmin:
        "branch_admin",
    };

    const normalized =
      aliases[role] ||
      role;

    if (
      !Object.prototype.hasOwnProperty.call(
        WORKSPACE_BOOTSTRAP_TABLES,
        normalized,
      )
    ) {
      throw new BadRequestException(
        `Unsupported workspace role: ${role || "missing role"}.`,
      );
    }

    return normalized as WorkspaceBootstrapRole;
  }

  private async resolveWorkspaceMembership(
    actor: AuthUser,
    dto: WorkspaceBootstrapDto,
  ) {
    const accountId =
      this.requireActorAccount(
        actor,
        dto.accountId,
      );

    const requestedRole =
      dto.role
        ? this.normalizeWorkspaceRole(
            dto.role,
          )
        : undefined;

    const membership =
      await this.prisma.userMembership.findFirst({
        where: {
          accountId,
          userId: actor.id,
          active: true,
          status: "active",
          ...(dto.membershipId
            ? {
                id:
                  dto.membershipId,
              }
            : {}),
          ...(requestedRole
            ? {
                role: {
                  in:
                    this.membershipRoleCandidates(
                      requestedRole,
                    ),
                },
              }
            : {}),
        },
        orderBy: {
          createdAt: "asc",
        },
      });

    if (!membership) {
      throw new ForbiddenException(
        "The selected role membership is not active for this account.",
      );
    }

    const requestedSchoolId =
      this.cleanId(
        dto.schoolId,
      );

    const requestedBranchId =
      this.cleanId(
        dto.branchId,
      );

    if (
      membership.schoolId &&
      requestedSchoolId &&
      this.cleanId(
        membership.schoolId,
      ) !== requestedSchoolId
    ) {
      throw new ForbiddenException(
        "The selected school is outside this membership.",
      );
    }

    if (
      membership.branchId &&
      requestedBranchId &&
      this.cleanId(
        membership.branchId,
      ) !== requestedBranchId
    ) {
      throw new ForbiddenException(
        "The selected branch is outside this membership.",
      );
    }

    // Profile memberships must resolve to their own permanent linked ID.
    // This also protects legacy non-paginated workspace bootstrap.
    const membershipRole = this.normalizeWorkspaceRole(membership.role);
    const profileField: "teacherId" | "studentId" | "parentId" | null =
      membershipRole === "teacher" ? "teacherId"
        : membershipRole === "student" ? "studentId"
          : membershipRole === "parent" ? "parentId"
            : null;
    if (profileField) {
      const linkedId = this.cleanId((membership as any)[profileField]);
      const requestedId = this.cleanId((dto as any)[profileField]);
      if (!linkedId || (requestedId && requestedId !== linkedId)) {
        throw new ForbiddenException(
          `The selected ${profileField} is not linked to this membership.`,
        );
      }
    }

    return membership;
  }

  private membershipRoleCandidates(
    role: WorkspaceBootstrapRole,
  ) {
    if (role === "school_admin") {
      return [
        "school_admin",
        "admin",
      ];
    }

    if (role === "super_admin") {
      return [
        "super_admin",
        "owner",
      ];
    }

    return [role];
  }

  private async assertWorkspaceScope(
    input: {
      actor: AuthUser;
      role:
        WorkspaceBootstrapRole;
      schoolId?: string;
      branchId?: string;
      teacherId?: string;
      studentId?: string;
      parentId?: string;
    },
  ) {
    const {
      actor,
      role,
      schoolId,
      branchId,
      teacherId,
      studentId,
      parentId,
    } = input;

    if (
      [
        "branch_admin",
        "teacher",
        "student",
        "parent",
        "accountant",
      ].includes(role) &&
      !branchId
    ) {
      throw new BadRequestException(
        `${role} workspace bootstrap requires branchId.`,
      );
    }

    if (
      ![
        "developer",
        "platform_team",
        "super_admin",
      ].includes(role) &&
      !schoolId
    ) {
      throw new BadRequestException(
        `${role} workspace bootstrap requires schoolId.`,
      );
    }

    if (
      role === "teacher" &&
      !teacherId
    ) {
      throw new BadRequestException(
        "Teacher workspace bootstrap requires teacherId.",
      );
    }

    if (
      role === "student" &&
      !studentId
    ) {
      throw new BadRequestException(
        "Student workspace bootstrap requires studentId.",
      );
    }

    if (
      role === "parent" &&
      !parentId
    ) {
      throw new BadRequestException(
        "Parent workspace bootstrap requires parentId.",
      );
    }

    if (
      [
        "developer",
        "platform_team",
        "super_admin",
      ].includes(role)
    ) {
      return;
    }

    await this.assertActorTenantAccess(
      actor,
      branchId
        ? "schoolBranchSettings"
        : "academicPeriods",
      {
        schoolId,
        branchId,
      },
    );
  }

  private workspaceBootstrapTables(
    role: WorkspaceBootstrapRole,
    requested?: string[],
  ) {
    const allowed =
      new Set(
        WORKSPACE_BOOTSTRAP_TABLES[
          role
        ],
      );

    if (
      !requested ||
      !requested.length
    ) {
      return [...allowed];
    }

    const filtered =
      requested
        .map((table) =>
          this.cleanTableName(
            table,
          ),
        )
        .filter(
          (
            table,
          ): table is string =>
            Boolean(
              table &&
              allowed.has(
                table,
              ) &&
              LOCAL_FIRST_TABLES.has(
                table,
              ),
            ),
        );

    return filtered.length
      ? [...new Set(filtered)]
      : [...allowed];
  }

  private filterWorkspaceBootstrapRecords(
    records: any[],
    scope: WorkspaceReadScope,
  ) {
    const tenantMatches = (record: any): boolean =>
      this.recordMatchesWorkspaceTenant(record, scope.schoolId, scope.branchId);
    const live = (record: any): boolean =>
      !record.isDeleted && record.payload?.isDeleted !== true &&
      record.payload?.active !== false && tenantMatches(record);
    const recordId = (record: any): string | undefined =>
      this.cleanId(record.payload?.id || record.localId);

    // Preserve existing parent-child authorization.
    const childStudentIds = new Set<string>();
    if (scope.role === "parent" && scope.parentId) {
      for (const record of records) {
        if (record.tableName !== "studentParents" || !live(record)) continue;
        const payload = (record.payload || {}) as Record<string, any>;
        if (this.cleanId(payload.parentId) === scope.parentId) {
          const id = this.cleanId(payload.studentId);
          if (id) childStudentIds.add(id);
        }
      }
    }

    // Class permissions come from stored, active tenant-scoped assignments,
    // NOT a client-provided class list or the frontend's filter selection.
    const assignedClassIds = new Set<string>();
    const enrolledStudentIds = new Set<string>();
    const assignedClassSubjectIds = new Set<string>();
    const visibleTeacherIds = new Set<string>();
    const visibleReportCardIds = new Set<string>();

    if (scope.role === "teacher" && scope.teacherId) {
      visibleTeacherIds.add(scope.teacherId);

      // Pass 1: determine which classes the logged-in teacher is assigned.
      for (const record of records) {
        if (!live(record) ||
            (record.tableName !== "classTeachers" &&
             record.tableName !== "classSubjects")) continue;
        const p = record.payload || {};
        if (this.cleanId(p.teacherId) === scope.teacherId) {
          const classId = this.cleanId(p.classId);
          if (classId) assignedClassIds.add(classId);
        }
      }

      // Pass 2: find other subject teachers and student enrollment records
      // related to those classes. Names are only returned for such colleagues.
      for (const record of records) {
        if (!live(record)) continue;
        const p = record.payload || {};
        const classId = this.cleanId(p.classId);
        if (!classId || !assignedClassIds.has(classId)) continue;

        if (record.tableName === "classTeachers" ||
            record.tableName === "classSubjects") {
          const colleagueId = this.cleanId(p.teacherId);
          if (colleagueId) visibleTeacherIds.add(colleagueId);
          if (record.tableName === "classSubjects") {
            const id = recordId(record);
            if (id) assignedClassSubjectIds.add(id);
          }
        }
        if (record.tableName === "studentEnrollments" &&
            p.status === "active") {
          const studentId = this.cleanId(p.studentId);
          if (studentId) enrolledStudentIds.add(studentId);
        }
      }

      // Pass 3: report items can be authorized through their reportCardId.
      for (const record of records) {
        if (!live(record) || record.tableName !== "reportCards") continue;
        const p = record.payload || {};
        const classId = this.cleanId(p.classId);
        const studentId = this.cleanId(p.studentId);
        const allowedByClass = Boolean(classId && assignedClassIds.has(classId));
        const allowedByStudent = Boolean(
          studentId && enrolledStudentIds.has(studentId) &&
          (!classId || assignedClassIds.has(classId)),
        );
        if (allowedByClass || allowedByStudent) {
          const id = recordId(record);
          if (id) visibleReportCardIds.add(id);
        }
      }
    }

    const roleScopedNonMedia = records.filter((record) => {
      if (record.tableName === "mediaAssets") return false;
      if (!tenantMatches(record)) return false;
      if (scope.role === "student" && scope.studentId) {
        return this.recordMatchesStudentWorkspace(record, scope.studentId);
      }
      if (scope.role === "parent" && scope.parentId) {
        return this.recordMatchesParentWorkspace(record, scope.parentId, childStudentIds);
      }
      if (scope.role === "teacher") {
        if (!scope.teacherId) return false;
        return this.recordMatchesTeacherWorkspace(record, scope.teacherId, {
          assignedClassIds,
          enrolledStudentIds,
          assignedClassSubjectIds,
          visibleTeacherIds,
          visibleReportCardIds,
        });
      }
      return true;
    });

    // An asset is visible only if its owner record is authorized.
    const allowedOwnerIds = new Map<string, Set<string>>();
    for (const record of roleScopedNonMedia) {
      const id = recordId(record);
      if (!id) continue;
      const ids = allowedOwnerIds.get(record.tableName) || new Set<string>();
      ids.add(id);
      allowedOwnerIds.set(record.tableName, ids);
    }

    const profileScoped = ["student", "parent", "teacher"].includes(scope.role);
    const scopedMedia = records.filter((record) => {
      if (record.tableName !== "mediaAssets" || !tenantMatches(record)) return false;
      const p = (record.payload || {}) as Record<string, any>;
      const ownerTable = this.cleanString(p.ownerTable);
      const ownerId = this.cleanId(p.ownerId);

      // Name-only colleague profiles must NEVER cause their private media
      // (contracts, signatures, documents, photos) to be downloaded.
      if (scope.role === "teacher" && ownerTable === "teachers" &&
          ownerId !== scope.teacherId) return false;

      if (ownerTable && ownerId) {
        return Boolean(allowedOwnerIds.get(ownerTable)?.has(ownerId));
      }
      return !profileScoped;
    });

    // Keep stable record order for pagination.
    const authorized = new Set([...roleScopedNonMedia, ...scopedMedia]);
    return records.filter((record) => authorized.has(record));
  }

  private recordMatchesWorkspaceTenant(
    record: any,
    schoolId?: string,
    branchId?: string,
  ) {
    const payload =
      (record.payload || {}) as Record<
        string,
        any
      >;

    const recordSchoolId =
      this.cleanId(
        payload.schoolId ||
          (
            record.tableName ===
            "schools"
              ? payload.id ||
                record.localId
              : undefined
          ),
      );

    const recordBranchId =
      this.cleanId(
        payload.branchId ||
          (
            record.tableName ===
            "branches"
              ? payload.id ||
                record.localId
              : undefined
          ),
      );

    if (
      schoolId &&
      recordSchoolId &&
      recordSchoolId !==
        schoolId
    ) {
      return false;
    }

    if (
      branchId &&
      recordBranchId &&
      recordBranchId !==
        branchId
    ) {
      return false;
    }

    if (
      BRANCH_REQUIRED_TABLES.has(
        record.tableName,
      ) &&
      branchId &&
      recordBranchId !==
        branchId
    ) {
      return false;
    }

    if (
      SCHOOL_REQUIRED_TABLES.has(
        record.tableName,
      ) &&
      schoolId &&
      recordSchoolId !==
        schoolId
    ) {
      return false;
    }

    return true;
  }

  private recordMatchesStudentWorkspace(
    record: any,
    studentId: string,
  ) {
    const sharedTables =
      new Set([
        "schools",
        "branches",
        "schoolBranchSettings",
        "identityCredentialDesignSettings",
        "academicPeriods",
        "classes",
        "subjects",
        "classSubjects",
        "announcements",
        "identityDevices",
        "identityAccessPoints",
        "schoolVehicles",
        "transportRoutes",
        "transportStops",
        "transportJourneys",
        "emergencyRollCallSessions",
      ]);

    if (
      sharedTables.has(
        record.tableName,
      )
    ) {
      return true;
    }

    const payload =
      (record.payload || {}) as Record<
        string,
        any
      >;

    const directStudentId = this.cleanId(
      payload.studentId ||
        (
          record.tableName === "students"
            ? payload.id || record.localId
            : undefined
        ),
    );

    if (directStudentId === studentId) {
      return true;
    }

    const identitySubjectId = this.cleanId(
      payload.subjectId || payload.personId,
    );

    const identitySubjectType = String(
      payload.subjectType || payload.personType || "",
    ).toLowerCase();

    return (
      identitySubjectId === studentId &&
      identitySubjectType === "student"
    );
  }

  private recordMatchesParentWorkspace(
    record: any,
    parentId: string,
    childStudentIds:
      Set<string>,
  ) {
    const sharedTables =
      new Set([
        "schools",
        "branches",
        "schoolBranchSettings",
        "identityCredentialDesignSettings",
        "academicPeriods",
        "classes",
        "announcements",
        "identityDevices",
        "identityAccessPoints",
        "schoolVehicles",
        "transportRoutes",
        "transportStops",
        "transportJourneys",
        "emergencyRollCallSessions",
      ]);

    if (
      sharedTables.has(
        record.tableName,
      )
    ) {
      return true;
    }

    const payload =
      (record.payload || {}) as Record<
        string,
        any
      >;

    const recordParentId =
      this.cleanId(
        payload.parentId ||
          (
            record.tableName ===
            "parents"
              ? payload.id ||
                record.localId
              : undefined
          ),
      );

    if (
      recordParentId ===
      parentId
    ) {
      return true;
    }

    const studentId =
      this.cleanId(
        payload.studentId ||
          (
            record.tableName ===
            "students"
              ? payload.id ||
                record.localId
              : undefined
          ),
      );

    if (
      studentId &&
      childStudentIds.has(studentId)
    ) {
      return true;
    }

    const subjectId = this.cleanId(
      payload.subjectId || payload.personId,
    );

    const subjectType = String(
      payload.subjectType || payload.personType || "",
    ).toLowerCase();

    if (
      subjectType === "parent" &&
      subjectId === parentId
    ) {
      return true;
    }

    if (
      subjectType === "student" &&
      subjectId &&
      childStudentIds.has(subjectId)
    ) {
      return true;
    }

    const authorizedPersonId = this.cleanId(
      payload.authorizedPersonId ||
        payload.collectorSubjectId,
    );

    return Boolean(
      authorizedPersonId === parentId,
    );
  }

  private recordMatchesTeacherWorkspace(
    record: any,
    teacherId: string,
    access: {
      assignedClassIds: Set<string>;
      enrolledStudentIds: Set<string>;
      assignedClassSubjectIds: Set<string>;
      visibleTeacherIds: Set<string>;
      visibleReportCardIds: Set<string>;
    },
  ) {
    const {
      assignedClassIds, enrolledStudentIds, assignedClassSubjectIds,
      visibleTeacherIds, visibleReportCardIds,
    } = access;
    const p = (record.payload || {}) as Record<string, any>;
    const table = record.tableName;
    const id = this.cleanId(p.id || record.localId);
    const classId = this.cleanId(p.classId);
    const studentId = this.cleanId(p.studentId);
    const classSubjectId = this.cleanId(p.classSubjectId);
    const linkedTeacherId = this.cleanId(p.teacherId);

    if (table === "teachers") return Boolean(id && visibleTeacherIds.has(id));
    if (table === "classes") return Boolean(id && assignedClassIds.has(id));
    if (table === "classTeachers" || table === "classSubjects") {
      return Boolean(classId && assignedClassIds.has(classId));
    }
    if (table === "students") return Boolean(id && enrolledStudentIds.has(id));
    if (table === "studentEnrollments") {
      return Boolean(classId && assignedClassIds.has(classId));
    }
    if (table === "reportCards") return Boolean(id && visibleReportCardIds.has(id));
    if (table === "reportCardItems") {
      const reportCardId = this.cleanId(p.reportCardId);
      if (reportCardId) return visibleReportCardIds.has(reportCardId);
      // Legacy report items sometimes carry class/student instead of card ID.
      return Boolean(
        (classId && assignedClassIds.has(classId)) ||
        (studentId && enrolledStudentIds.has(studentId) &&
         (!classId || assignedClassIds.has(classId))),
      );
    }

    // The full class report includes scores entered by OTHER subject teachers.
    // Check every supplied relationship; never accept an unrelated class.
    if (["assessmentEntries", "computedResults", "assessmentComponents",
         "attendance", "studentAttendanceSummaries"].includes(table)) {
      if (classId && !assignedClassIds.has(classId)) return false;
      if (studentId && !enrolledStudentIds.has(studentId)) return false;
      if (classSubjectId && !assignedClassSubjectIds.has(classSubjectId)) return false;
      return Boolean(classId || studentId || classSubjectId);
    }
    if (table === "assessmentApplicabilities") {
      if (classId && !assignedClassIds.has(classId)) return false;
      if (classSubjectId && !assignedClassSubjectIds.has(classSubjectId)) return false;
      return true;
    }
    if (table === "teacherAttendance") return linkedTeacherId === teacherId;

    // Definitions/templates are shared within the scoped school or branch.
    const sharedDefinitions = new Set([
      "schools", "branches", "schoolBranchSettings", "academicPeriods",
      "subjects", "academicStructures", "gradingStructures", "gradeRules",
      "reportCardTemplates", "reportCardTemplateSettings",
      "reportCardTemplateAssignments", "assessmentStructures",
      "assessmentStructureItems", "identityDevices", "identityAccessPoints",
      "emergencyRollCallSessions",
    ]);
    if (sharedDefinitions.has(table)) return true;

    // Other existing teacher-associated records remain available ONLY if
    // their explicit class/student/subject linkage is also authorized.
    if (classId && !assignedClassIds.has(classId)) return false;
    if (studentId && !enrolledStudentIds.has(studentId)) return false;
    if (classSubjectId && !assignedClassSubjectIds.has(classSubjectId)) return false;
    if (linkedTeacherId === teacherId) return true;

    const subjectId = this.cleanId(p.subjectId || p.personId);
    const subjectType = String(p.subjectType || p.personType || "").toLowerCase();
    return subjectId === teacherId && ["teacher", "staff"].includes(subjectType);
  }

  /**
   * All read endpoints use this projection. Never return the full colleague
   * teacher profile to a different teacher membership.
   */
  private toBootstrapPullRecord(
    record: any,
    scope?: WorkspaceReadScope,
  ) {
    let payload = record.payload;
    let deviceId = record.deviceId || undefined;

    if (scope?.role === "teacher" && record.tableName === "teachers") {
      const original = (record.payload || {}) as Record<string, any>;
      const id = this.cleanId(original.id || record.localId);
      if (id !== scope.teacherId) {
        const display: Record<string, any> = {};
        for (const field of COLLEAGUE_TEACHER_DISPLAY_FIELDS) {
          if (original[field] !== undefined) display[field] = original[field];
        }
        display.id = id;
        payload = display;
        deviceId = undefined;
      }
    }

    return {
      tableName: record.tableName,
      localId: this.cleanString(record.localId),
      cloudId: record.id,
      accountId: record.accountId,
      deviceId,
      version: record.version,
      updatedAt: Number(record.updatedAt),
      isDeleted: record.isDeleted,
      payload,
    };
  }

  /** Invalid records cannot bypass teacher-profile projection in quarantine. */
  private toQuarantinePullRecord(
    record: any,
    reason: string,
    scope?: WorkspaceReadScope,
  ) {
    if (scope?.role === "teacher") {
      return {
        reason,
        record: {
          tableName: record.tableName,
          localId: this.cleanString(record.localId),
          cloudId: record.id,
          accountId: record.accountId,
          isDeleted: Boolean(record.isDeleted),
        },
      };
    }
    return { reason, record: this.toBootstrapPullRecord(record, scope) };
  }

  private buildWorkspaceSummary(
    records: any[],
    scope: {
      role:
        WorkspaceBootstrapRole;
      schoolId?: string;
      branchId?: string;
      teacherId?: string;
      studentId?: string;
      parentId?: string;
    },
  ) {
    const latest = (
      tableName: string,
      predicate?:
        (
          payload:
            Record<
              string,
              any
            >,
          record: any,
        ) => boolean,
    ) =>
      [...records]
        .reverse()
        .find(
          (record) => {
            if (
              record.tableName !==
              tableName
            ) {
              return false;
            }

            return predicate
              ? predicate(
                  record.payload ||
                    {},
                  record,
                )
              : true;
          },
        )?.payload ||
      null;

    const appearanceScope =
      this.appearanceScopeForWorkspaceRole(
        scope.role,
      );

    const exactBranchSettings =
      appearanceScope === "branch"
        ? latest(
            "schoolBranchSettings",
            (payload) =>
              (!scope.schoolId ||
                this.cleanId(payload.schoolId) === scope.schoolId) &&
              (!scope.branchId ||
                this.cleanId(payload.branchId) === scope.branchId),
          )
        : null;

    return {
      role:
        scope.role,
      appearanceScope,
      school:
        latest(
          "schools",
          (payload, record) =>
            !scope.schoolId ||
            this.cleanId(
              payload.id ||
                record.localId,
            ) ===
              scope.schoolId,
        ),
      branch:
        latest(
          "branches",
          (payload, record) =>
            !scope.branchId ||
            this.cleanId(
              payload.id ||
                record.localId,
            ) ===
              scope.branchId,
        ),
      // Branch settings are effective only for branch-scoped memberships.
      // They may still be present in the record bundle for management pages,
      // but they must never become the Owner/Developer/School portal theme.
      settings:
        exactBranchSettings,
      academicPeriod:
        latest(
          "academicPeriods",
          (payload) =>
            payload.active ===
              true ||
            payload.isCurrent ===
              true ||
            payload.current ===
              true,
        ) ||
        latest(
          "academicPeriods",
        ),
    };
  }

  private async lightweightWorkspacePlatformCache(
    actor: AuthUser,
    accountId: string,
  ) {
    const [
      account,
      user,
      memberships,
      permissionRules,
    ] = await Promise.all([
      this.prisma.account.findUnique({
        where: {
          id: accountId,
        },
      }),
      this.prisma.appUser.findUnique({
        where: {
          id: actor.id,
        },
        select: {
          id: true,
          accountId: true,
          fullName: true,
          email: true,
          phone: true,
          role: true,
          active: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      }),
      this.prisma.userMembership.findMany({
        where: {
          accountId,
          userId: actor.id,
          active: true,
        },
        orderBy: {
          createdAt: "asc",
        },
      }),
      this.prisma.permissionRule.findMany({
        where: {
          accountId,
        },
        orderBy: {
          moduleKey: "asc",
        },
      }),
    ]);

    const records: any[] = [];

    const add = (
      tableName: string,
      value: any,
    ) => {
      const rows =
        Array.isArray(value)
          ? value
          : value
            ? [value]
            : [];

      for (const row of rows) {
        const payload =
          this.sanitizePlatformCachePayload(tableName, this.toPlain(row));

        records.push({
          tableName,
          id:
            payload.id ||
            payload.accountId,
          cloudId:
            payload.id ||
            payload.accountId,
          accountId,
          updatedAt:
            payload.updatedAt ||
            payload.createdAt ||
            Date.now(),
          isDeleted: false,
          payload,
        });
      }
    };

    add(
      "accounts",
      account,
    );
    add(
      "appUsers",
      user,
    );
    add(
      "userMemberships",
      memberships,
    );
    add(
      "permissionRules",
      permissionRules,
    );

    return {
      records,
    };
  }

  private buildWorkspaceBootstrapRevision(
    input: {
      accountId: string;
      membershipId: string;
      role:
        WorkspaceBootstrapRole;
      schoolId?: string;
      branchId?: string;
      records: any[];
      platformRecords: any[];
    },
  ) {
    const signature = [
      input.accountId,
      input.membershipId,
      input.role,
      input.schoolId ||
        "",
      input.branchId ||
        "",
      ...input.records.map(
        (record) =>
          [
            record.cloudId,
            record.version,
            record.updatedAt,
            record.isDeleted
              ? 1
              : 0,
          ].join(":"),
      ),
      ...input.platformRecords.map(
        (record) =>
          [
            record.tableName,
            record.cloudId,
            record.updatedAt,
          ].join(":"),
      ),
    ].join("|");

    /**
     * A compact deterministic revision without adding a database column.
     */
    let hash = 2166136261;

    for (
      let index = 0;
      index <
      signature.length;
      index += 1
    ) {
      hash ^=
        signature.charCodeAt(
          index,
        );

      hash =
        Math.imul(
          hash,
          16777619,
        );
    }

    return (
      "ws-" +
      (hash >>> 0)
        .toString(16)
        .padStart(8, "0")
    );
  }

  private async ensureAccount(accountId: string) {
    const existing = await this.prisma.account.findUnique({ where: { id: accountId } });
    if (existing) return existing;

    return this.prisma.account.create({
      data: { id: accountId, name: "Local Account", email: null, status: "active" },
    });
  }

  /**
   * Student-only authoritative write path. Every other sync table retains its
   * original upsert behaviour. Admission identity and SyncRecord are committed
   * in one serializable transaction (including any legacy identity backfill).
   */
  private async upsertStudentWithAdmission(record: NormalizedSyncPushRecord) {
    const accountId = this.cleanId(record.accountId);
    const studentId = this.requireLocalId(record.localId, "students");
    const schoolId = this.cleanId(record.payload?.schoolId);
    const branchId = this.cleanId(record.payload?.branchId);
    if (!accountId || !schoolId || !branchId) {
      throw new BadRequestException("Student must have accountId, schoolId and branchId.");
    }

    // Retrying a SERIALIZABLE transaction must retry *all* its reads/writes.
    let saved: any;
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        saved = await this.prisma.$transaction(async (tx) => {
          const existing = await tx.syncRecord.findFirst({
            where: { accountId, tableName: "students", localId: studentId },
            orderBy: [{ updatedAt: "desc" }, { createdAt: "desc" }],
          });
          if (record.cloudId) {
            const byCloud = await tx.syncRecord.findUnique({ where: { id: record.cloudId } });
            if (byCloud && (byCloud.accountId !== accountId || byCloud.tableName !== "students" || byCloud.localId !== studentId)) {
              throw new ForbiddenException("Student cloud identity does not match its permanent UUID.");
            }
          }
          if (existing) {
            const oldPayload = (existing.payload || {}) as Record<string, any>;
            if (this.cleanId(oldPayload.schoolId) !== schoolId || this.cleanId(oldPayload.branchId) !== branchId) {
              throw new BadRequestException("Moving a student to another branch requires a separate authorized transfer workflow.");
            }
            const incomingVersion = Number(record.version || 1);
            const incomingUpdatedAt = Number(record.updatedAt || Date.now());
            if (!(incomingVersion > existing.version || incomingUpdatedAt >= Number(existing.updatedAt))) {
              // Preserve the accepted record; a stale write must not allocate a number.
              return { ...existing, admissionStale: true };
            }
          }

          // Register historical admissions before making any allocation. Never
          // silently choose one if distinct student UUIDs share the same number.
          // This also prevents new numbers from colliding with unbackfilled data.
          const branchStudents = await tx.syncRecord.findMany({
            where: { accountId, tableName: "students", isDeleted: false },
            orderBy: [{ updatedAt: "desc" }, { createdAt: "desc" }],
          });
          const deduped = new Map<string, Record<string, any>>();
          for (const row of branchStudents) {
            const p = (row.payload || {}) as Record<string, any>;
            if (this.cleanId(p.schoolId) !== schoolId || this.cleanId(p.branchId) !== branchId) continue;
            const id = this.cleanId(p.id || row.localId);
            if (id && !deduped.has(id)) deduped.set(id, p);
          }
          for (const [id, p] of deduped) {
            if (id === studentId) continue; // current student is processed below
            const raw = String(p.admissionNumber ?? "").trim();
            if (!raw) continue;
            const norm = this.admissionNumbers.normalizeNumber(raw);
            const matched = await tx.studentAdmissionIdentity.findUnique({
              where: { accountId_studentId: { accountId, studentId: id } },
            });
            if (matched) {
              if (matched.schoolId !== schoolId || matched.branchId !== branchId || matched.normalizedNumber !== norm) {
                throw new BadRequestException("Historical admission identity conflict: reconciliation is required.");
              }
              continue;
            }
            await tx.studentAdmissionIdentity.create({
              data: { accountId, schoolId, branchId, studentId: id, admissionNumber: raw, normalizedNumber: norm },
            });
          }

          // Deletion does not release an assigned number for reuse.
          if (record.isDeleted) {
            const newPayload = { ...record.payload, accountId };
            if (existing) return tx.syncRecord.update({
              where: { id: existing.id },
              data: { deviceId: record.deviceId || existing.deviceId, version: record.version, updatedAt: BigInt(record.updatedAt), isDeleted: true, payload: { ...newPayload, cloudId: existing.id } },
            });
            return tx.syncRecord.create({
              data: { accountId, tableName: "students", localId: studentId, cloudId: record.cloudId || undefined, deviceId: record.deviceId || undefined, version: record.version, updatedAt: BigInt(record.updatedAt), isDeleted: true, payload: newPayload },
            });
          }

          const settings = await tx.syncRecord.findMany({
            where: { accountId, tableName: "schoolBranchSettings", isDeleted: false },
            orderBy: [{ updatedAt: "desc" }, { createdAt: "desc" }],
          });
          const settingsPayload = settings.map(s => (s.payload || {}) as Record<string, any>)
            .find(p => this.cleanId(p.schoolId) === schoolId && this.cleanId(p.branchId) === branchId);
          const config = this.admissionNumbers.normalizeConfig(settingsPayload?.admissionNumbers);
          const oldNumber = String(((existing?.payload || {}) as any).admissionNumber || "").trim();
          // Protect the already-issued number of the current student as legacy
          // data, including when the branch has since switched to auto mode.
          if (oldNumber) {
            const registered = await tx.studentAdmissionIdentity.findUnique({
              where: { accountId_studentId: { accountId, studentId } },
            });
            const norm = this.admissionNumbers.normalizeNumber(oldNumber);
            if (!registered) {
              await tx.studentAdmissionIdentity.create({
                data: { accountId, schoolId, branchId, studentId,
                  admissionNumber: oldNumber, normalizedNumber: norm },
              });
            } else if (registered.normalizedNumber !== norm || registered.schoolId !== schoolId || registered.branchId !== branchId) {
              throw new BadRequestException("Existing student admission identity conflicts with the registry.");
            }
          }
          const supplied = String(record.payload.admissionNumber || oldNumber || "").trim();
          const provisional = config.mode === "automatic" ||
            (config.mode === "automatic_or_manual" && record.payload.admissionNumberProvisional === true);
          // In mixed mode, a provisional number is reassigned. In manual mode
          // and for historical confirmed IDs, existing values are retained.
          const assignment = await this.admissionNumbers.assignInTransaction(tx, {
            accountId, schoolId, branchId, studentId, supplied,
            provisionalAutomatic: provisional && !oldNumber,
            config,
          });
          const payload = {
            ...record.payload,
            accountId,
            id: studentId,
            admissionNumber: assignment?.admissionNumber || supplied || undefined,
            admissionNumberProvisional: false,
            admissionNumberConfirmed: Boolean(assignment),
          };
          if (existing) {
            return tx.syncRecord.update({
              where: { id: existing.id },
              data: { localId: studentId, cloudId: existing.id, deviceId: record.deviceId || existing.deviceId,
                version: record.version, updatedAt: BigInt(record.updatedAt), isDeleted: false,
                payload: { ...payload, cloudId: existing.id } },
            });
          }
          const created = await tx.syncRecord.create({
            data: { accountId, tableName: "students", localId: studentId,
              deviceId: record.deviceId || undefined, version: record.version,
              updatedAt: BigInt(record.updatedAt), isDeleted: false, payload },
          });
          return tx.syncRecord.update({
            where: { id: created.id },
            data: { cloudId: created.id, payload: { ...payload, cloudId: created.id } },
          });
        }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable, timeout: 30000 });
        break;
      } catch (error: any) {
        if ((error?.code === "P2034" || error?.code === "P2002") && attempt < 3) continue;
        throw error;
      }
    }
    if (!saved) throw new Error("Student admission transaction failed.");
    if (saved.admissionStale) {
      const conflict = await this.recordConflict({ existing: saved, incoming: record, reason: "version_conflict" });
      return { ...saved, conflictId: conflict?.id };
    }
    await this.afterUpsertRecord(saved, record);
    return saved;
  }

  private async upsertRecord(record: NormalizedSyncPushRecord) {
    if (record.tableName === "students") return this.upsertStudentWithAdmission(record);
    const accountId = this.cleanId(record.accountId);

    if (!accountId) {
      throw new Error("Account session is missing. Please log out and sign in again.");
    }

    const localId = this.requireLocalId(
      record.localId,
      record.tableName,
    );
    const storedLocalId = this.localIdToStorageString(
      localId,
      record.tableName,
    );
    const cloudId = this.cleanString(record.cloudId);
    const deviceId = this.cleanString(record.deviceId);
    const now = Date.now();
    const updatedAt = BigInt(Number(record.updatedAt || now));

    const basePayload = {
      ...(record.payload || {}),
      accountId,
      cloudId: cloudId || record.payload?.cloudId,
    };

    const payload =
      record.tableName === MEDIA_ASSETS_TABLE
        ? this.normalizeMediaPayload(
            basePayload,
            accountId,
            deviceId,
            Boolean(record.isDeleted),
          )
        : basePayload;

    const existing = await this.findExistingSyncRecord({
      accountId,
      tableName: record.tableName,
      cloudId,
      localId,
      deviceId,
      payload,
    });

    if (existing) {
      if (existing.accountId !== accountId) {
        throw new Error("This synced record belongs to another account. Please clear local app data and sign in again.");
      }

      const incomingVersion = Number(record.version || 1);
      const incomingUpdatedAt = Number(record.updatedAt || now);
      const existingUpdatedAt = Number(existing.updatedAt);
      const incomingIsNewer = incomingVersion > existing.version || incomingUpdatedAt >= existingUpdatedAt;

      if (!incomingIsNewer) {
        const conflict = await this.recordConflict({ existing, incoming: record, reason: "version_conflict" });
        return { ...existing, conflictId: conflict?.id } as any;
      }

      const saved = await this.prisma.syncRecord.update({
        where: { id: existing.id },
        data: {
          tableName: record.tableName,
          localId: storedLocalId,
          cloudId: cloudId || existing.cloudId || existing.id,
          deviceId,
          version: incomingVersion,
          updatedAt,
          isDeleted: Boolean(record.isDeleted),
          payload: {
            ...payload,
            cloudId: cloudId || existing.cloudId || existing.id,
          },
        },
      });

      await this.afterUpsertRecord(saved, record);

      return saved;
    }

    const saved = await this.prisma.syncRecord.create({
      data: {
        accountId,
        tableName: record.tableName,
        localId: storedLocalId,
        cloudId: cloudId || undefined,
        deviceId,
        version: Number(record.version || 1),
        updatedAt,
        isDeleted: Boolean(record.isDeleted),
        payload,
      },
    });

    await this.afterUpsertRecord(saved, record);

    return saved;
  }

  private async findExistingSyncRecord(args: {
    accountId: string;
    tableName: string;
    cloudId?: string;
    localId?: string;
    deviceId?: string;
    payload: Record<string, any>;
  }) {
    if (args.cloudId) {
      const byCloudId = await this.prisma.syncRecord.findUnique({ where: { id: args.cloudId } });
      if (byCloudId) return byCloudId;
    }

    if (args.tableName === MEDIA_ASSETS_TABLE) {
      const mediaExisting = await this.findExistingMediaSyncRecord(args);
      if (mediaExisting) return mediaExisting;
    }

    return this.prisma.syncRecord.findFirst({
      where: {
        accountId: args.accountId,
        tableName: args.tableName,
        localId:
          args.localId === undefined
            ? undefined
            : this.localIdToStorageString(
                args.localId,
                args.tableName,
              ),
        ...(args.deviceId ? { deviceId: args.deviceId } : {}),
      },
      orderBy: { createdAt: "desc" },
    });
  }

  private async findExistingMediaSyncRecord(args: {
    accountId: string;
    tableName: string;
    cloudId?: string;
    localId?: string;
    deviceId?: string;
    payload: Record<string, any>;
  }) {
    const payload = args.payload || {};

    const ownerTable = this.cleanString(payload.ownerTable);
    const fieldKey = this.cleanString(payload.fieldKey);
    const ownerId = this.cleanId(payload.ownerId);
    const ownerTempKey = this.cleanString(payload.ownerTempKey);

    /*
     * The permanent client-generated media UUID is the first and strongest
     * identity. Do not include deviceId: the same media asset may be pushed
     * again from another device after pull/bootstrap.
     */
    if (args.localId) {
      const byLocalId = await this.prisma.syncRecord.findFirst({
        where: {
          accountId: args.accountId,
          tableName: MEDIA_ASSETS_TABLE,
          localId: this.localIdToStorageString(
            args.localId,
            MEDIA_ASSETS_TABLE,
          ),
        },
        orderBy: { updatedAt: "desc" },
      });

      if (byLocalId) return byLocalId;
    }

    /*
     * Multi-image fields intentionally share ownerTable + ownerId + fieldKey.
     * A new localId therefore means a new sibling asset, never a replacement.
     */
    if (this.isMultiMediaField(fieldKey)) {
      return null;
    }

    const ownerIdentityKey =
      this.cleanString(payload.ownerIdentityKey) ||
      this.buildMediaIdentityKey({
        accountId: args.accountId,
        ownerTable,
        fieldKey,
        ownerId,
        ownerTempKey,
      });

    if (ownerIdentityKey) {
      const candidates = await this.prisma.syncRecord.findMany({
        where: {
          accountId: args.accountId,
          tableName: MEDIA_ASSETS_TABLE,
          payload: {
            path: ["ownerIdentityKey"],
            equals: ownerIdentityKey,
          },
        },
        orderBy: { updatedAt: "desc" },
        take: 20,
      });

      const exact = candidates.find((row: any) => {
        const candidatePayload = (row.payload || {}) as Record<string, any>;
        return (
          this.cleanString(candidatePayload.ownerIdentityKey) === ownerIdentityKey &&
          this.cleanString(candidatePayload.ownerTable) === ownerTable &&
          this.cleanString(candidatePayload.fieldKey) === fieldKey
        );
      });

      if (exact) return exact;
    }

    if (ownerId && ownerTable && fieldKey) {
      const candidates = await this.prisma.syncRecord.findMany({
        where: {
          accountId: args.accountId,
          tableName: MEDIA_ASSETS_TABLE,
          payload: { path: ["ownerId"], equals: ownerId },
        },
        orderBy: { updatedAt: "desc" },
        take: 50,
      });

      const exact = candidates.find((row: any) => {
        const candidatePayload = (row.payload || {}) as Record<string, any>;
        return (
          this.cleanId(candidatePayload.ownerId) === ownerId &&
          this.cleanString(candidatePayload.ownerTable) === ownerTable &&
          this.cleanString(candidatePayload.fieldKey) === fieldKey
        );
      });

      if (exact) return exact;
    }

    if (ownerTempKey && ownerTable && fieldKey) {
      const candidates = await this.prisma.syncRecord.findMany({
        where: {
          accountId: args.accountId,
          tableName: MEDIA_ASSETS_TABLE,
          payload: { path: ["ownerTempKey"], equals: ownerTempKey },
        },
        orderBy: { updatedAt: "desc" },
        take: 50,
      });

      const exact = candidates.find((row: any) => {
        const candidatePayload = (row.payload || {}) as Record<string, any>;
        return (
          this.cleanString(candidatePayload.ownerTempKey) === ownerTempKey &&
          this.cleanString(candidatePayload.ownerTable) === ownerTable &&
          this.cleanString(candidatePayload.fieldKey) === fieldKey
        );
      });

      if (exact) return exact;
    }

    return null;
  }

  private isMultiMediaField(
    fieldKey?: string | null,
  ): boolean {
    const normalizedFieldKey =
      this.cleanString(fieldKey) || "";

    return MULTI_MEDIA_FIELD_KEYS.has(
      normalizedFieldKey,
    );
  }

  private async afterUpsertRecord(
    saved: any,
    incoming: NormalizedSyncPushRecord,
  ) {
    if (
      incoming.tableName !==
      MEDIA_ASSETS_TABLE
    ) {
      return;
    }

    const originalPayload =
      (saved.payload || {}) as Record<
        string,
        any
      >;

    const normalizedPayload =
      this.normalizeMediaPayload(
        {
          ...originalPayload,
          cloudId: saved.id,
        },
        saved.accountId,
        this.cleanString(
          saved.deviceId ||
            incoming.deviceId,
        ),
        Boolean(
          saved.isDeleted ||
            incoming.isDeleted,
        ),
      );

    const payloadChanged =
      originalPayload.cloudId !==
        saved.id ||
      originalPayload.ownerIdentityKey !==
        normalizedPayload.ownerIdentityKey ||
      Number(
        originalPayload.identityVersion ||
          0,
      ) !== 1 ||
      originalPayload.deviceId !==
        normalizedPayload.deviceId;

    let finalRecord = saved;

    if (payloadChanged) {
      finalRecord =
        await this.prisma.syncRecord.update({
          where: {
            id: saved.id,
          },
          data: {
            cloudId:
              saved.cloudId ||
              saved.id,
            payload:
              normalizedPayload,
          },
        });
    }

    const finalPayload =
      (finalRecord.payload || {}) as Record<string, any>;

    if (
      !this.isMultiMediaField(
        this.cleanString(finalPayload.fieldKey),
      )
    ) {
      await this.deactivateReplacedMediaAssets(
        finalRecord,
      );
    }
  }

  private async deactivateReplacedMediaAssets(
    activeRecord: any,
  ) {
    const activePayload =
      (activeRecord.payload || {}) as Record<
        string,
        any
      >;

    const accountId =
      activeRecord.accountId;

    if (
      activeRecord.tableName !==
      MEDIA_ASSETS_TABLE
    ) {
      return;
    }

    if (
      activeRecord.isDeleted ||
      activePayload.active === false ||
      activePayload.isDeleted
    ) {
      return;
    }

    const ownerTable =
      this.cleanString(
        activePayload.ownerTable,
      );

    const fieldKey =
      this.cleanString(
        activePayload.fieldKey,
      );

    // Collection fields preserve every active sibling asset.
    if (this.isMultiMediaField(fieldKey)) {
      return;
    }

    const ownerId =
      this.cleanId(
        activePayload.ownerId,
      );

    const ownerTempKey =
      this.cleanString(
        activePayload.ownerTempKey,
      );

    const deviceId =
      this.cleanString(
        activePayload.deviceId ||
          activeRecord.deviceId,
      );

    const activeIdentityKey =
      this.cleanString(
        activePayload.ownerIdentityKey,
      ) ||
      this.buildMediaIdentityKey({
        accountId,
        ownerTable,
        fieldKey,
        ownerId,
        ownerTempKey,
      });

    if (
      !ownerTable ||
      !fieldKey ||
      !activeIdentityKey
    ) {
      return;
    }

    const candidates =
      await this.prisma.syncRecord.findMany({
        where: {
          accountId,
          tableName:
            MEDIA_ASSETS_TABLE,
          NOT: {
            id: activeRecord.id,
          },
        },
        orderBy: {
          updatedAt: "desc",
        },
        take: 500,
      });

    const now =
      BigInt(Date.now());

    const updates:
      Promise<any>[] = [];

    for (
      const candidate of
      candidates
    ) {
      const payload =
        (candidate.payload || {}) as Record<
          string,
          any
        >;

      if (
        candidate.isDeleted ||
        payload.isDeleted ||
        payload.active === false
      ) {
        continue;
      }

      if (
        this.cleanString(
          payload.ownerTable,
        ) !== ownerTable ||
        this.cleanString(
          payload.fieldKey,
        ) !== fieldKey
      ) {
        continue;
      }

      const candidateIdentityKey =
        this.cleanString(
          payload.ownerIdentityKey,
        ) ||
        this.buildMediaIdentityKey({
          accountId,
          ownerTable:
            this.cleanString(
              payload.ownerTable,
            ),
          fieldKey:
            this.cleanString(
              payload.fieldKey,
            ),
          ownerId:
            this.cleanId(
              payload.ownerId,
            ),
          ownerTempKey:
            this.cleanString(
              payload.ownerTempKey,
            ),
        });

      if (
        candidateIdentityKey !==
        activeIdentityKey
      ) {
        continue;
      }

      updates.push(
        this.prisma.syncRecord.update({
          where: {
            id: candidate.id,
          },
          data: {
            isDeleted: true,
            updatedAt: now,
            version:
              Number(
                candidate.version ||
                  1,
              ) + 1,
            payload: {
              ...payload,
              ownerIdentityKey:
                candidateIdentityKey,
              identityVersion: 1,
              active: false,
              isDeleted: true,
              replacedByCloudId:
                activeRecord.id,
              replacedAt:
                Number(now),
            },
          },
        }),
      );
    }

    if (updates.length) {
      await Promise.all(
        updates,
      );
    }
  }

  private async recordConflict(args: { existing: any; incoming: NormalizedSyncPushRecord; reason: string }) {
    try {
      const conflict = await this.prisma.syncConflict.create({
        data: {
          accountId: args.existing.accountId,
          tableName: args.existing.tableName,
          localId: this.localIdToStorageString(
            args.incoming.localId,
            args.existing.tableName,
          ),
          cloudId: args.existing.id,
          deviceId: args.incoming.deviceId,
          conflictType: args.reason,
          status: "open",
          severity: "medium",
          serverPayload: args.existing.payload || {},
          clientPayload: args.incoming.payload || {},
        },
      });

      this.realtime.emitConflictCreated({
        accountId: args.existing.accountId,
        tableName: args.existing.tableName,
        sourceDeviceId: args.incoming.deviceId,
        metadata: { conflictId: conflict.id, reason: args.reason },
      });

      return conflict;
    } catch {
      return null;
    }
  }

  private async touchDevice(args: {
    accountId: string;
    userId?: string;
    deviceId?: string | null;
    lastSeenAt?: Date;
    lastPushAt?: Date;
    lastPullAt?: Date;
  }) {
    const deviceId = this.cleanString(args.deviceId);
    if (!deviceId) return;

    try {
      await this.prisma.syncDevice.upsert({
        where: { accountId_deviceId: { accountId: args.accountId, deviceId } },
        update: {
          userId: args.userId || undefined,
          lastSeenAt: args.lastSeenAt || new Date(),
          lastPushAt: args.lastPushAt,
          lastPullAt: args.lastPullAt,
          active: true,
        },
        create: {
          accountId: args.accountId,
          userId: args.userId,
          deviceId,
          platform: "web",
          lastSeenAt: args.lastSeenAt || new Date(),
          lastPushAt: args.lastPushAt,
          lastPullAt: args.lastPullAt,
          active: true,
        },
      });
    } catch {
      // Device tracking should never break normal sync.
    }
  }

  /**
   * Resolve a stable compound pull cursor.
   *
   * New clients send cursorUpdatedAt + cursorId together. Older clients may
   * still send only `since`, which is handled separately by pull().
   *
   * Incomplete compound cursors are rejected because accepting only one side
   * could skip records that share the same timestamp.
   */
  private resolvePullCursor(dto: PullSyncDto): SyncPullCursor | null {
    const hasUpdatedAt =
      dto.cursorUpdatedAt !== undefined &&
      dto.cursorUpdatedAt !== null;

    const hasId = Boolean(this.cleanString(dto.cursorId));

    if (hasUpdatedAt !== hasId) {
      throw new BadRequestException(
        "cursorUpdatedAt and cursorId must be supplied together.",
      );
    }

    if (!hasUpdatedAt || !hasId) {
      return null;
    }

    const updatedAt = Number(dto.cursorUpdatedAt);
    const id = this.cleanString(dto.cursorId);

    if (!Number.isFinite(updatedAt) || updatedAt < 0 || !id) {
      throw new BadRequestException("Invalid synchronization cursor.");
    }

    return {
      updatedAt,
      id,
    };
  }

  private async validateIncomingSyncRecord(
    actor: AuthUser,
    record: NormalizedSyncPushRecord,
    activeAccountId: string,
  ) {
    const tableName =
      this.cleanTableName(
        record.tableName,
      );

    const accountId =
      this.cleanId(
        record.accountId,
      );

    if (
      !tableName ||
      BLOCKED_PUSH_TABLES.has(
        tableName,
      ) ||
      !LOCAL_FIRST_TABLES.has(
        tableName,
      )
    ) {
      throw new ForbiddenException(
        `${tableName || "Unknown table"} is not allowed to be pushed from the browser.`,
      );
    }

    if (
      !accountId ||
      accountId !==
        activeAccountId
    ) {
      throw new BadRequestException(
        "The synchronization record accountId does not match the active account.",
      );
    }

    this.requireLocalId(
      record.localId,
      tableName,
    );

    if (
      !Number.isFinite(
        Number(record.version),
      ) ||
      Number(record.version) <= 0
    ) {
      throw new BadRequestException(
        `${tableName} has an invalid version.`,
      );
    }

    if (
      !this.isValidSyncTimestamp(
        record.updatedAt,
      )
    ) {
      throw new BadRequestException(
        `${tableName} has an invalid updatedAt timestamp.`,
      );
    }

    if (
      !this.isPlainJsonObject(
        record.payload,
      )
    ) {
      throw new BadRequestException(
        `${tableName} payload must be a valid JSON object.`,
      );
    }

    const payloadAccountId =
      this.cleanId(
        record.payload.accountId,
      );

    if (
      payloadAccountId !==
        activeAccountId
    ) {
      throw new BadRequestException(
        `${tableName} payload belongs to another account.`,
      );
    }

    this.validateTenantFields(
      tableName,
      record.payload,
    );

    await this.assertActorTenantAccess(
      actor,
      tableName,
      record.payload,
      this.requireLocalId(
        record.localId,
        tableName,
      ),
    );
  }

  private async validateStoredPullRecord(
    actor: AuthUser,
    record: any,
    activeAccountId: string,
  ): Promise<{
    ok: boolean;
    reason?: string;
  }> {
    const reasons: string[] = [];

    const tableName =
      this.cleanTableName(
        record?.tableName,
      );

    if (
      !tableName ||
      !LOCAL_FIRST_TABLES.has(
        tableName,
      )
    ) {
      reasons.push(
        "TABLE_NOT_PULLABLE",
      );
    }

    if (
      this.cleanId(
        record?.accountId,
      ) !== activeAccountId
    ) {
      reasons.push(
        "ACCOUNT_MISMATCH",
      );
    }

    if (!this.isValidUuid(record?.localId)) {
      reasons.push(
        "INVALID_LOCAL_ID",
      );
    }

    if (
      !Number.isFinite(
        Number(record?.version),
      ) ||
      Number(record?.version) <= 0
    ) {
      reasons.push(
        "INVALID_VERSION",
      );
    }

    if (
      !this.isValidSyncTimestamp(
        record?.updatedAt,
      )
    ) {
      reasons.push(
        "INVALID_TIMESTAMP",
      );
    }

    if (
      !this.isPlainJsonObject(
        record?.payload,
      )
    ) {
      reasons.push(
        "INVALID_JSON_PAYLOAD",
      );
    } else {
      if (
        this.cleanId(
          record.payload.accountId,
        ) !== activeAccountId
      ) {
        reasons.push(
          "PAYLOAD_ACCOUNT_MISMATCH",
        );
      }

      if (tableName) {
        try {
          this.validateTenantFields(
            tableName,
            record.payload,
          );

          await this.assertActorTenantAccess(
            actor,
            tableName,
            record.payload,
            record.localId,
          );
        } catch (error: any) {
          reasons.push(
            error?.message ||
              "INVALID_TENANT_FIELDS",
          );
        }
      }
    }

    return {
      ok:
        reasons.length === 0,
      reason:
        reasons.join(" | ") ||
        undefined,
    };
  }

  private validateTenantFields(
    tableName: string,
    payload: Record<string, any>,
  ) {
    const requiresSchool =
      SCHOOL_REQUIRED_TABLES.has(
        tableName,
      ) ||
      BRANCH_REQUIRED_TABLES.has(
        tableName,
      );

    if (
      requiresSchool &&
      !this.cleanId(
        payload.schoolId,
      )
    ) {
      throw new BadRequestException(
        `${tableName} requires a valid schoolId.`,
      );
    }

    if (
      BRANCH_REQUIRED_TABLES.has(
        tableName,
      ) &&
      !this.cleanId(
        payload.branchId,
      )
    ) {
      throw new BadRequestException(
        `${tableName} requires a valid branchId.`,
      );
    }
  }

  private isValidSyncTimestamp(
    value: unknown,
  ) {
    const timestamp =
      Number(value);

    return (
      Number.isFinite(
        timestamp,
      ) &&
      timestamp > 0 &&
      timestamp <=
        Date.now() +
          24 * 60 * 60 * 1000
    );
  }

  private isPlainJsonObject(
    value: unknown,
  ): value is Record<string, any> {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value)
    ) {
      return false;
    }

    const prototype =
      Object.getPrototypeOf(
        value,
      );

    return (
      prototype ===
        Object.prototype ||
      prototype === null
    );
  }

  private normalizeMediaPayload(
    payload: Record<string, any>,
    accountId: string,
    recordDeviceId?: string,
    isDeleted = false,
  ) {
    const ownerTable = this.cleanString(payload.ownerTable);
    const fieldKey = this.cleanString(payload.fieldKey);
    const ownerId = this.cleanId(payload.ownerId);
    const ownerTempKey = this.cleanString(payload.ownerTempKey);
    const deviceId = this.cleanString(payload.deviceId || recordDeviceId);

    const ownerIdentityKey = this.buildMediaIdentityKey({
      accountId,
      ownerTable,
      fieldKey,
      ownerId,
      ownerTempKey,
    });

    const active =
      payload.active !== false &&
      payload.isDeleted !== true &&
      !isDeleted;

    if (
      active &&
      (!ownerTable || !fieldKey || !ownerIdentityKey)
    ) {
      throw new BadRequestException(
        "Active mediaAssets require accountId, ownerTable, fieldKey, and ownerId or ownerTempKey.",
      );
    }

    return {
      ...payload,
      accountId,
      ownerTable,
      ownerId,
      ownerTempKey,
      fieldKey,
      deviceId,
      ownerIdentityKey,
      identityVersion: 2,
    };
  }

  private buildMediaIdentityKey(input: {
    accountId?: string;
    ownerTable?: string;
    fieldKey?: string;
    ownerId?: string;
    ownerTempKey?: string;
  }) {
    const accountId = this.cleanString(input.accountId);
    const ownerTable = this.cleanString(input.ownerTable);
    const fieldKey = this.cleanString(input.fieldKey);

    if (!accountId || !ownerTable || !fieldKey) {
      return undefined;
    }

    const encode = (value: string | number) =>
      encodeURIComponent(String(value));

    if (input.ownerId) {
      return [
        encode(accountId),
        encode(ownerTable),
        encode(fieldKey),
        "owner",
        encode(input.ownerId),
      ].join("|");
    }

    if (input.ownerTempKey) {
      return [
        encode(accountId),
        encode(ownerTable),
        encode(fieldKey),
        "temp",
        encode(input.ownerTempKey),
      ].join("|");
    }

    return undefined;
  }

  private cleanString(value?: string | null) {
    const clean = String(value || "").trim();
    return clean.length ? clean : undefined;
  }

  private cleanId(value?: string | null) {
    return this.cleanString(value);
  }

  private cleanTableName(value?: string | null) {
    const clean = this.cleanString(value);
    if (!clean) return undefined;
    return clean.replace(/[^a-zA-Z0-9_]/g, "");
  }

  private cleanNumber(value?: number | string | null) {
    if (value === undefined || value === null || value === "") return undefined;
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? n : undefined;
  }

  private isValidUuid(value: unknown): value is string {
    const clean = this.cleanString(
      value === undefined || value === null
        ? undefined
        : String(value),
    );

    return Boolean(
      clean &&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
          clean,
        ),
    );
  }

  private requireLocalId(
    value: number | string | null | undefined,
    tableName?: string,
  ): string {
    const localId = this.cleanString(
      value === undefined || value === null
        ? undefined
        : String(value),
    );

    if (!localId || !this.isValidUuid(localId)) {
      throw new BadRequestException(
        `${tableName || "Sync record"} has no valid UUID localId.`,
      );
    }

    return localId;
  }

  /**
   * Prisma stores SyncRecord.localId and SyncConflict.localId as strings.
   * UUID local IDs are persisted exactly as generated by the client.
   */
  private localIdToStorageString(
    value: number | string | null | undefined,
    tableName?: string,
  ): string {
    return this.requireLocalId(
      value,
      tableName,
    );
  }

  private sanitizePayload(payload: Record<string, any>, tableName?: string) {
    const source = { ...(payload || {}) };

    delete source.password;
    delete source.passwordHash;
    delete source.refreshToken;
    delete source.refreshTokenHash;
    delete source.keyHash;
    delete source.secret;
    delete source.secretHash;

    if (tableName === MEDIA_ASSETS_TABLE) {
      const safeMediaPayload: Record<string, any> = {};

      for (const key of SAFE_MEDIA_ASSET_FIELDS) {
        if (source[key] !== undefined) {
          safeMediaPayload[key] = this.toPlain(source[key]);
        }
      }

      delete safeMediaPayload.blob;
      delete safeMediaPayload.file;
      delete safeMediaPayload.fileBlob;
      delete safeMediaPayload.originalFile;
      delete safeMediaPayload.optimizedFile;
      delete safeMediaPayload.localBlob;
      delete safeMediaPayload.localBlobData;
      delete safeMediaPayload.localBlobId;
      delete safeMediaPayload.data;
      delete safeMediaPayload.binary;
      delete safeMediaPayload.buffer;
      delete safeMediaPayload.arrayBuffer;
      delete safeMediaPayload.objectUrl;
      delete safeMediaPayload.localObjectUrl;
      delete safeMediaPayload.localPreviewUrl;
      delete safeMediaPayload.previewUrl;

      for (const key of [
        "remoteUrl",
        "publicUrl",
        "thumbnailDataUrl",
        "previewDataUrl",
      ]) {
        const value =
          safeMediaPayload[key];

        if (
          typeof value === "string" &&
          value.startsWith("blob:")
        ) {
          delete safeMediaPayload[key];
        }
      }

      return safeMediaPayload;
    }

    delete source.blob;
    delete source.file;
    delete source.fileBlob;
    delete source.originalFile;
    delete source.optimizedFile;
    delete source.localBlob;
    delete source.localBlobData;
    delete source.localBlobId;
    delete source.data;
    delete source.binary;
    delete source.buffer;
    delete source.arrayBuffer;
    delete source.objectUrl;
    delete source.localObjectUrl;
    delete source.localPreviewUrl;
    delete source.previewUrl;
    delete source.base64;
    delete source.thumbnailBase64;
    delete source.previewDataUrl;
    delete source.thumbnailDataUrl;

    return this.removeInlineMediaStrings(source);
  }

  private removeInlineMediaStrings(value: any): any {
    if (value === null || value === undefined) return value;

    if (typeof value === "string") {
      if (
        value.startsWith("data:image/") ||
        value.startsWith("data:application/") ||
        value.startsWith("blob:")
      ) {
        return "";
      }

      return value;
    }

    if (Array.isArray(value)) {
      return value.map((item) => this.removeInlineMediaStrings(item));
    }

    if (value instanceof Date) return value.toISOString();
    if (typeof value === "bigint") return Number(value);

    if (typeof value === "object") {
      const cleaned: Record<string, any> = {};
      for (const [key, item] of Object.entries(value)) {
        if (item !== undefined) cleaned[key] = this.removeInlineMediaStrings(item);
      }
      return cleaned;
    }

    return value;
  }

  private toPlain(value: any): any {
    if (value === null || value === undefined) return value;
    if (typeof value === "bigint") return Number(value);
    if (value instanceof Date) return value.toISOString();
    if (Array.isArray(value)) return value.map((v) => this.toPlain(v));

    if (typeof value === "object") {
      const out: any = {};
      for (const [key, val] of Object.entries(value)) {
        if (val !== undefined) out[key] = this.toPlain(val);
      }
      return out;
    }

    return value;
  }

  private safeSyncError(error: any) {
    return error?.message || "Sync failed for this record.";
  }
}
