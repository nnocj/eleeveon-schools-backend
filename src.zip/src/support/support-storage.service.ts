/** Private Supabase Storage for Eleeveon Center chat attachments and Hub backgrounds. */
import { BadRequestException, Injectable, ServiceUnavailableException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { randomUUID } from "node:crypto";

export type SupportAttachment = {
  name: string; mimeType: string; sizeBytes: number; storageKey: string;
  kind: "image" | "video" | "audio" | "document"; encrypted?: boolean;
};
export type SupportFile = { originalname?: string; mimetype?: string; size?: number; buffer?: Buffer };
const ALLOWED = new Map<string, string>([
  ["image/jpeg", ".jpg"], ["image/png", ".png"], ["image/webp", ".webp"],
  ["image/gif", ".gif"], ["image/avif", ".avif"],
  ["video/mp4", ".mp4"], ["video/webm", ".webm"], ["video/quicktime", ".mov"],
  ["audio/webm", ".webm"], ["audio/ogg", ".ogg"], ["audio/mpeg", ".mp3"],
  ["audio/mp4", ".m4a"], ["audio/x-m4a", ".m4a"], ["audio/wav", ".wav"],
  ["audio/x-wav", ".wav"], ["audio/aac", ".aac"],
  ["application/pdf", ".pdf"], ["text/plain", ".txt"],
  ["application/msword", ".doc"],
  ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"],
  ["application/vnd.ms-excel", ".xls"],
  ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"],
  ["application/vnd.ms-powerpoint", ".ppt"],
  ["application/vnd.openxmlformats-officedocument.presentationml.presentation", ".pptx"],
  ["application/zip", ".zip"], ["application/x-zip-compressed", ".zip"],
]);

function safeSegment(value: string): string { return value.replace(/[^a-zA-Z0-9_-]/g, "_"); }
function sniffImage(buffer: Buffer): { mimeType: string; ext: string } | null {
  if (buffer.length >= 8 && buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))
    return {mimeType:"image/png",ext:".png"};
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff)
    return {mimeType:"image/jpeg",ext:".jpg"};
  if (buffer.length >= 12 && buffer.toString("ascii",0,4) === "RIFF" && buffer.toString("ascii",8,12) === "WEBP")
    return {mimeType:"image/webp",ext:".webp"};
  if (buffer.length >= 6 && ["GIF87a","GIF89a"].includes(buffer.toString("ascii",0,6)))
    return {mimeType:"image/gif",ext:".gif"};
  if (buffer.length >= 12 && buffer.toString("ascii",4,8) === "ftyp" &&
      ["avif","avis"].includes(buffer.toString("ascii",8,12)))
    return {mimeType:"image/avif",ext:".avif"};
  return null;
}

@Injectable()
export class SupportStorageService {
  private readonly storage: SupabaseClient;
  private readonly bucket: string;
  readonly maxBytes: number;
  constructor(private readonly config: ConfigService) {
    const url = config.get<string>("SUPABASE_URL")?.trim();
    const secret = config.get<string>("SUPABASE_SECRET_KEY")?.trim();
    this.bucket = config.get<string>("SUPABASE_SUPPORT_BUCKET")?.trim() || "eleeveon-support";
    const configured = Number(config.get<string>("SUPPORT_MAX_FILE_SIZE_BYTES") || 15 * 1024 * 1024);
    this.maxBytes = Number.isFinite(configured) && configured > 0 ? Math.min(configured, 50 * 1024 * 1024) : 15 * 1024 * 1024;
    if (!url || !secret) throw new Error("SUPABASE_URL and SUPABASE_SECRET_KEY are required for support attachments.");
    this.storage = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
  }

  async store(accountId: string, feedbackId: string, file: SupportFile, encrypted = false): Promise<SupportAttachment> {
    if (!file?.buffer?.length || !Buffer.isBuffer(file.buffer)) throw new BadRequestException("Select a non-empty attachment.");
    const rawType = String(file.mimetype || "").toLowerCase().split(";")[0].trim();
    const mimeType = rawType === "video/mp4" && file.originalname?.toLowerCase().endsWith(".m4a") ? "audio/mp4" : rawType;
    const extension = encrypted && mimeType === "application/octet-stream" ? ".e2ee" : ALLOWED.get(mimeType);
    if (encrypted && mimeType !== "application/octet-stream") throw new BadRequestException("Expected an encrypted attachment.");
    if (!extension) throw new BadRequestException("This file type is not supported. Choose an image, audio, video, document or ZIP file.");
    if (file.buffer.length > this.maxBytes) throw new BadRequestException(`Attachment exceeds the ${Math.ceil(this.maxBytes / 1024 / 1024)} MB limit.`);
    const name = String(file.originalname || "attachment").replace(/[\\/\r\n\x00-\x1f]/g, "_").slice(0, 160);
    const storageKey = `${safeSegment(accountId)}/${safeSegment(feedbackId)}/${randomUUID()}${extension}`;
    const { error } = await this.storage.storage.from(this.bucket).upload(storageKey, file.buffer, {
      contentType: mimeType, cacheControl: "3600", upsert: false,
    });
    if (error) throw new ServiceUnavailableException(`Private support attachment upload failed: ${error.message}`);
    const kind: SupportAttachment["kind"] = mimeType.startsWith("image/") ? "image" : mimeType.startsWith("audio/") ? "audio" : mimeType.startsWith("video/") ? "video" : "document";
    return { name: encrypted ? "encrypted.bin" : name, mimeType, sizeBytes: file.buffer.length, storageKey, kind, encrypted };
  }

  async reserveDirectUpload(accountId:string,feedbackId:string){
    const storageKey=`${safeSegment(accountId)}/${safeSegment(feedbackId)}/${randomUUID()}.e2ee`;
    const {data,error}=await this.storage.storage.from(this.bucket).createSignedUploadUrl(storageKey);
    if(error||!data?.signedUrl)throw new ServiceUnavailableException("Cannot prepare private media upload.");
    return {storageKey,signedUrl:data.signedUrl};
  }
  async confirmDirectUpload(storageKey:string,expectedBytes:number):Promise<SupportAttachment>{
    const {data,error}=await this.storage.storage.from(this.bucket).info(storageKey);
    if(error||!data)throw new BadRequestException("The encrypted upload has not completed.");
    if(Number(data.size)!==expectedBytes)throw new BadRequestException("Uploaded file size does not match the reserved encrypted file.");
    if(data.contentType&&data.contentType.split(";")[0]!=="application/octet-stream")throw new BadRequestException("The direct-upload content type must be application/octet-stream.");
    return {name:"encrypted.bin",mimeType:"application/octet-stream",sizeBytes:expectedBytes,storageKey,kind:"document",encrypted:true};
  }

  /** Only for the authenticated user's Hub background (not E2EE chat media). */
  async storeBackground(accountId: string, userId: string, file?: SupportFile) {
    if (!file?.buffer?.length || !Buffer.isBuffer(file.buffer) || file.buffer.length > 6 * 1024 * 1024) {
      throw new BadRequestException("Choose a non-empty image up to 6 MB.");
    }
    const sniffed = sniffImage(file.buffer);
    if (!sniffed) throw new BadRequestException("Choose a valid PNG, JPG, WebP, GIF or AVIF image.");
    const name = String(file.originalname || `Background${sniffed.ext}`).replace(/[\\/\r\n\x00-\x1f]/g, "_").slice(0, 120);
    const storageKey = `${safeSegment(accountId)}/hub-backgrounds/${safeSegment(userId)}/${randomUUID()}${sniffed.ext}`;
    const { error } = await this.storage.storage.from(this.bucket).upload(storageKey,file.buffer,
      {contentType:sniffed.mimeType,cacheControl:"300",upsert:false});
    if (error) throw new ServiceUnavailableException("Could not upload Hub background.");
    return { storageKey, name, mimeType: sniffed.mimeType, sizeBytes: file.buffer.length };
  }
  async backgroundUrl(storageKey: string): Promise<string | null> {
    const { data, error } = await this.storage.storage.from(this.bucket).createSignedUrl(storageKey, 600);
    return error ? null : data?.signedUrl || null;
  }

  async remove(storageKey:string):Promise<void>{
    const {error}=await this.storage.storage.from(this.bucket).remove([storageKey]);
    if (error) throw new ServiceUnavailableException("Could not delete private media.");
  }
  async signedUrl(attachment: SupportAttachment): Promise<string | null> {
    const { data, error } = await this.storage.storage.from(this.bucket).createSignedUrl(
      attachment.storageKey, 600,
      attachment.kind === "document" ? { download: attachment.name } : undefined,
    );
    if (error) return null;
    return data?.signedUrl || null;
  }
}
